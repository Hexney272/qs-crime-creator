--──────────────────────────────────────────────────────────────────────────────
--  Quasar Store · Configuration Guidelines
--──────────────────────────────────────────────────────────────────────────────
--  • [EDIT] – Safe to modify.
--  • [INFO] – Explains what the setting/block does.
--  • [ADV]  – Advanced option; change only if you understand the impact.
--  • [CORE] – Core logic; do not edit unless you are a developer.
--  • [AUTO] – Auto-detected/managed by the system; never edit manually.
--──────────────────────────────────────────────────────────────────────────────

-- Illegal Furnitures                                                            [EDIT]
-- [INFO] Objects not allowed inside houses (police can remove). Keys are model names.
Config.IllegalFurnitures = {}

-- Dynamic Furnitures                                                            [ADV]
-- [INFO] Custom events for objects (not for 'stash' or 'wardrobe' types). First param = unique id.
Config.DynamicFurnitures = {}

-- Example:
-- RegisterNetEvent('need-to-change:peep', function(uniq)
--     print('uniq', uniq)
-- end)

-- Furniture Navigation (UI)                                                     [EDIT]
-- [INFO] Top navigation for decorator UI. Images must exist under Config.ImagePath.
Config.FurnitureNavigation = {
    [1] = {
        label = 'Kitchen',
        img = Config.ImagePath .. 'decorate/categories/topbar/kitchen.svg',
        background = Config.ImagePath .. 'decorate/categories/rooms/background/indoor.png',
        path = 'kitchen'
    },
    [2] = {
        label = 'Bathroom',
        img = Config.ImagePath .. 'decorate/categories/topbar/bathroom.svg',
        background = Config.ImagePath .. 'decorate/categories/rooms/background/indoor.png',
        path = 'bathroom'
    },
    [3] = {
        label = 'Bedroom',
        img = Config.ImagePath .. 'decorate/categories/topbar/bedroom.svg',
        background = Config.ImagePath .. 'decorate/categories/rooms/background/indoor.png',
        path = 'bedroom'
    },
    [4] = {
        label = 'Living',
        img = Config.ImagePath .. 'decorate/categories/topbar/living-room.svg',
        background = Config.ImagePath .. 'decorate/categories/rooms/background/indoor.png',
        path = 'living'
    },
    [5] = {
        label = 'Garden',
        img = Config.ImagePath .. 'decorate/categories/topbar/garden.svg',
        background = Config.ImagePath .. 'decorate/categories/rooms/background/garden-background.png',
        path = 'garden'
    }
}

-- Furniture Catalog                                                             [EDIT]
-- [INFO] Categories and their items. To add functionality per item:
--        type='wardrobe' + offset{x,y,z}  OR  type='stash' + offset{x,y,z} + stash{maxweight,slots}
Config.Furniture = {
    -- Data for each category of furniture
    ['washingmachine'] = {
        label = 'Washing machine',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-washingmachine-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-washingmachine-blue.svg',
        css = {
            width = 4.5,
            top = 5.5,
            left = 2.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_rub_washer_01.png',
                ['object'] = 'prop_rub_washer_01',
                ['price'] = 250,
                ['label'] = 'Broken washing',
                ['description'] = 'Old and dirty washing machine, its cheap at least.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_01.png',
                ['object'] = 'prop_washer_01',
                ['price'] = 250,
                ['label'] = 'Old washing',
                ['description'] = 'Old and dirty washing machine, it is cheap at least, better than the previous one if it is...',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_02.png',
                ['object'] = 'prop_washer_02',
                ['price'] = 400,
                ['label'] = 'Clear washing',
                ['description'] = 'A beautiful washing machine, at a good price and completely new.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_03.png',
                ['object'] = 'prop_washer_03',
                ['price'] = 460,
                ['label'] = 'Deluxe washing',
                ['description'] = 'The best washing machine on the market, it performs all washing and drying functions in minutes!',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/v_ret_fh_dryer.png',
                ['object'] = 'v_ret_fh_dryer',
                ['price'] = 360,
                ['label'] = 'Simple modern washing',
                ['description'] = 'A simple washing machine of good quality and modern, a luxury among the economical!',
                ['colorlabel'] = 'New',
                ['colors'] = {
                    {
                        label = 'Old',
                        object = 'v_ret_fh_washmach',
                        price = 310,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 50000,
                            slots = 3
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bathroom/items/washing/bkr_prop_prtmachine_dryer_spin.png',
                ['object'] = 'bkr_prop_prtmachine_dryer_spin',
                ['price'] = 1390,
                ['label'] = 'Money washing',
                ['description'] = 'They say Pablo Escobar laundered his money here.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            }
        }
    },
    ['toilet'] = {
        label = 'Toilet',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-toiletseat-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-toiletseat-blue.svg',
        css = {
            width = 3.0,
            top = 3.8,
            left = 9.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/toilet/prop_ld_toilet_01.png',
                ['object'] = 'prop_ld_toilet_01',
                ['price'] = 200,
                ['label'] = 'Old toilet',
                ['description'] = 'Vintage-style toilet, classic design with enduring charm.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                toilet = {
                    animationOffset = vec4(-0.4, -0.0, 0.2, 0.0),
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/toilet/prop_toilet_01.png',
                ['object'] = 'prop_toilet_01',
                ['price'] = 350,
                ['label'] = 'Modern toilet',
                ['description'] = 'Sleek, eco-friendly modern toilet with advanced hygiene features.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                toilet = {
                    animationOffset = vec4(-0.4, -0.0, 0.2, 0.0),
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/toilet/prop_toilet_02.png',
                ['object'] = 'prop_toilet_02',
                ['price'] = 450,
                ['label'] = 'Black toilet',
                ['description'] = 'A beautiful toilet, with black and white details, minimalist.',
                ['colorlabel'] = 'Black',
                ['colors'] = {},
                toilet = {
                    animationOffset = vec4(-0.4, -0.0, 0.2, 0.0),
                }
            }
        }
    },
    ['toiletpaper'] = {
        label = 'Toilet paper',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-paper-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-paper-blue.svg',
        css = {
            width = 1.5,
            top = 4.1,
            left = 7.9,
            zIndex = 1
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/paper/prop_toilet_roll_01.png',
                ['object'] = 'prop_toilet_roll_01',
                ['price'] = 20,
                ['label'] = 'Lying paper',
                ['description'] = 'Soft, strong toilet paper for comfortable, effective use.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/paper/prop_toilet_roll_02.png',
                ['object'] = 'prop_toilet_roll_02',
                ['price'] = 40,
                ['label'] = 'Anchored paper',
                ['description'] = 'Secure, stable toilet paper with reliable dispensing.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/paper/prop_toilet_roll_05.png',
                ['object'] = 'prop_toilet_roll_05',
                ['price'] = 90,
                ['label'] = 'Store paper',
                ['description'] = 'Paper hanger for shops.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['toiletbrush'] = {
        label = 'Toilet brush',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-brush-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-brush-blue.svg',
        css = {
            width = 1.0,
            top = 6.1,
            left = 8.6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/brush/prop_toilet_brush_01.png',
                ['object'] = 'prop_toilet_brush_01',
                ['price'] = 50,
                ['label'] = 'Toilet brush',
                ['description'] = 'Durable, efficient toilet brush for thorough, hygienic cleaning.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['shower'] = {
        label = 'Shower',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-shower-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-shower-blue.svg',
        css = {
            width = 3.5,
            top = 0.9,
            left = 13.6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/shower/v_res_mbath.png',
                ['object'] = 'v_res_mbath',
                ['price'] = 400,
                ['label'] = 'Bath',
                ['description'] = 'Relaxing, spacious bath for ultimate comfort and serenity.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                bath = {
                    animationOffset = vec4(0.0, -0.5, 0.2, 20.0),
                    waterFallOffset = vec3(0.0, 0.79, 0.8),
                    fillOffset = vec3(0.0, 0.0, -0.2)
                }
            }
        }
    },
    ['mirror'] = {
        label = 'Mirror',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-mirror-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-mirror-blue.svg',
        css = {
            width = 2.0,
            top = 2.1,
            left = 5.2
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/mirror/p_int_jewel_mirror.png',
                ['object'] = 'p_int_jewel_mirror',
                ['price'] = 180,
                ['label'] = 'Mirror',
                ['description'] = 'Elegant, reflective mirror enhancing space and light.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['handtowel'] = {
        label = 'Hand towel',
        img = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-towel-blue.svg',
        navigation = 2,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bathroom/bathroom-towel-blue.svg',
        css = {
            width = 3.0,
            top = 4.2,
            left = 17.6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/p_shower_towel_s.png',
                ['object'] = 'p_shower_towel_s',
                ['price'] = 50,
                ['label'] = 'Hand dryer',
                ['description'] = 'Efficient, fast-drying, eco-friendly hand dryer.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_beach_towel_01.png',
                ['object'] = 'prop_beach_towel_01',
                ['price'] = 60,
                ['label'] = 'Hanging towel',
                ['description'] = 'Blue towel that comes in a complete or single pack.',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Complete',
                        object = 'prop_beach_towel_04',
                        price = 60
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_ftowel_01.png',
                ['object'] = 'prop_ftowel_01',
                ['price'] = 85,
                ['label'] = 'Lying towel',
                ['description'] = 'Soft, luxurious towel, perfect for lounging and relaxation.',
                ['colorlabel'] = 'Animal Print',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_ftowel_07.png',
                ['object'] = 'prop_ftowel_07',
                ['price'] = 120,
                ['label'] = 'Pile of towels blue',
                ['description'] = 'Pile of beautiful blue towels.',
                ['colorlabel'] = 'Blue',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_ftowel_08.png',
                ['object'] = 'prop_ftowel_08',
                ['price'] = 150,
                ['label'] = 'Pile of colorful towels',
                ['description'] = 'Many towels of many different colors.',
                ['colorlabel'] = 'Light colors',
                ['colors'] = {
                    {
                        label = 'Dark colors',
                        object = 'prop_ftowel_10',
                        price = 60
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_tint_towel.png',
                ['object'] = 'prop_tint_towel',
                ['price'] = 90,
                ['label'] = 'Wall towel',
                ['description'] = 'Simple wall towel, hanger and all.',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Pink',
                        object = 'prop_towel2_02',
                        price = 60
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_towel_rail_01.png',
                ['object'] = 'prop_towel_rail_01',
                ['price'] = 150,
                ['label'] = 'Bathroom towel',
                ['description'] = 'Beautiful stand with towel included.',
                ['colorlabel'] = 'Double',
                ['colors'] = {
                    {
                        label = 'Single',
                        object = 'v_res_mbtowel',
                        price = 200
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_towel_rail_02.png',
                ['object'] = 'prop_towel_rail_02',
                ['price'] = 95,
                ['label'] = 'Bathroom towel hand',
                ['description'] = 'Beautiful holder with included towel for hands.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/towel/prop_towel_shelf_01.png',
                ['object'] = 'prop_towel_shelf_01',
                ['price'] = 250,
                ['label'] = 'Towel table',
                ['description'] = 'A table loaded with multicolored towels.',
                ['colorlabel'] = 'Colors',
                ['colors'] = {}
            }
        }
    },
    ['chair'] = {
        label = 'Chair',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-chairs-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-chairs-blue.svg',
        css = {
            width = 4.0,
            top = 8.3,
            left = 17.5,
            zIndex = 3
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_din_chair_08.png',
                ['object'] = 'apa_mp_h_din_chair_08',
                ['price'] = 90,
                ['label'] = 'Plastic chair',
                ['description'] = 'White plastic chair with metal legs, simple and minimalist.',
                ['colorlabel'] = 'Square white',
                ['colors'] = {
                    {
                        label = 'Round white',
                        object = 'apa_mp_h_din_chair_04',
                        price = 90
                    },
                    {
                        label = 'Round yellow',
                        object = 'hei_heist_din_chair_01',
                        price = 90
                    },
                    {
                        label = 'Round blue',
                        object = 'hei_heist_din_chair_06',
                        price = 90
                    },
                    {
                        label = 'Round purple',
                        object = 'gr_prop_gr_chair02_ped',
                        price = 90
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_din_chair_09.png',
                ['object'] = 'apa_mp_h_din_chair_09',
                ['price'] = 95,
                ['label'] = 'Metal chair with leather',
                ['description'] = 'A simple metal chair with leather.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_din_chair_12.png',
                ['object'] = 'apa_mp_h_din_chair_12',
                ['price'] = 100,
                ['label'] = 'Wood chair',
                ['description'] = 'Simple wooden chair, with plastered wood.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_stn_chairarm_09.png',
                ['object'] = 'apa_mp_h_stn_chairarm_09',
                ['price'] = 190,
                ['label'] = 'Luxurious chair',
                ['description'] = 'Beautiful and minimalist chair, it looks expensive, but its on sale.',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_stn_chairarm_11.png',
                ['object'] = 'apa_mp_h_stn_chairarm_11',
                ['price'] = 150,
                ['label'] = 'Old chair',
                ['description'] = 'Antique rustic chair, one of the most comfortable at Quasar Store.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_stn_chairarm_12.png',
                ['object'] = 'apa_mp_h_stn_chairarm_12',
                ['price'] = 250,
                ['label'] = 'Modern chair',
                ['description'] = 'Modern black leather chair, beautiful for sitting in front of the computer.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_stn_chairarm_13.png',
                ['object'] = 'apa_mp_h_stn_chairarm_13',
                ['price'] = 130,
                ['label'] = 'Modern plastic chair',
                ['description'] = 'Modern yellow plastic chair, simple and cheap.',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/apa_mp_h_stn_chairstool_12.png',
                ['object'] = 'apa_mp_h_stn_chairstool_12',
                ['price'] = 80,
                ['label'] = 'Black armchair',
                ['description'] = 'Small armchair for kitchen tables, beautiful and small.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/bkr_prop_biker_boardchair01.png',
                ['object'] = 'bkr_prop_biker_boardchair01',
                ['price'] = 80,
                ['label'] = 'Computer chair',
                ['description'] = 'Modern and useful computer chair, it looks so comfortable.',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Green',
                        object = 'hei_prop_heist_off_chair',
                        price = 90
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/bkr_prop_clubhouse_chair_01.png',
                ['object'] = 'bkr_prop_clubhouse_chair_01',
                ['price'] = 25,
                ['label'] = 'Old and broken chair',
                ['description'] = 'Modern and useful computer chair, it looks so comfortable.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/ex_prop_offchair_exec_01.png',
                ['object'] = 'ex_prop_offchair_exec_01',
                ['price'] = 200,
                ['label'] = 'Executive chair',
                ['description'] = 'Large black executive chair, could be useful in offices.',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Executive chair brown',
                        object = 'imp_prop_impexp_offchair_01a',
                        price = 90
                    },
                    {
                        label = 'Executive old chair',
                        object = 'bkr_prop_clubhouse_offchair_01a',
                        price = 90
                    }
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/gr_prop_highendchair_gr_01a.png',
                ['object'] = 'gr_prop_highendchair_gr_01a',
                ['price'] = 550,
                ['label'] = 'Gaming chair',
                ['description'] = 'AKRacing gaming chair, the best on the market.',
                ['colorlabel'] = 'Red',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/hei_heist_stn_chairarm_06.png',
                ['object'] = 'hei_heist_stn_chairarm_06',
                ['price'] = 120,
                ['label'] = 'Elegant chair',
                ['description'] = 'Elegant and minimalist chair, beautiful for luxury homes.',
                ['colorlabel'] = 'Purple',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/hei_prop_hei_skid_chair.png',
                ['object'] = 'hei_prop_hei_skid_chair',
                ['price'] = 35,
                ['label'] = 'Camping chair',
                ['description'] = 'Camping chair to go out and have your barbecues with friends.',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Dark green',
                        object = 'prop_skid_chair_01',
                        price = 35
                    },
                    {
                        label = 'Blue',
                        object = 'prop_skid_chair_02',
                        price = 35
                    }
                }
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/p_dinechair_01_s.png',
                ['object'] = 'p_dinechair_01_s',
                ['price'] = 55,
                ['label'] = 'Single chair',
                ['description'] = 'Classic wooden chair, with fabric cover.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_01a.png',
                ['object'] = 'prop_chair_01a',
                ['price'] = 55,
                ['label'] = 'Kiosk chair',
                ['description'] = 'Aluminum chair for kiosks and outdoors.',
                ['colorlabel'] = 'Metal',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_01b.png',
                ['object'] = 'prop_chair_01b',
                ['price'] = 70,
                ['label'] = 'Kiosk wood chair',
                ['description'] = 'Aluminum and wood chair for kiosks and outdoors.',
                ['colorlabel'] = 'Metal and wood',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_02.png',
                ['object'] = 'prop_chair_02',
                ['price'] = 75,
                ['label'] = 'Kiosk wood advanced chair',
                ['description'] = 'Aluminum and wood advanced chair for kiosks and outdoors.',
                ['colorlabel'] = 'Metal and wood',
                ['colors'] = {}
            },
            [19] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_03.png',
                ['object'] = 'prop_chair_03',
                ['price'] = 120,
                ['label'] = 'Oak wood chair',
                ['description'] = 'Oak chair with beautiful antique decorations.',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [20] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_07.png',
                ['object'] = 'prop_chair_07',
                ['price'] = 90,
                ['label'] = 'Single wood chair',
                ['description'] = 'Simple rustic oak wood chair.',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [21] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_08.png',
                ['object'] = 'prop_chair_08',
                ['price'] = 30,
                ['label'] = 'Outdoor chair',
                ['description'] = 'Ice cream parlor or outdoor patio chair.',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Outdoor chair pile',
                        object = 'prop_chair_pile_01',
                        price = 200
                    }
                }
            },
            [22] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chair_09.png',
                ['object'] = 'prop_chair_09',
                ['price'] = 95,
                ['label'] = 'Steel and plastic chair',
                ['description'] = 'Metal chair with plastic-colored details, beautiful for outdoors.',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [23] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_chateau_chair_01.png',
                ['object'] = 'prop_chateau_chair_01',
                ['price'] = 85,
                ['label'] = 'Orange fabric chair',
                ['description'] = 'Outdoor chair with beautiful orange details, a very colorful chair that expresses happiness.',
                ['colorlabel'] = 'Orange',
                ['colors'] = {}
            },
            [24] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_direct_chair_01.png',
                ['object'] = 'prop_direct_chair_01',
                ['price'] = 350,
                ['label'] = 'Cinema chair',
                ['description'] = 'Film directors chair, one of the best to be inspired by movies like E.T.',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [25] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_gc_chair02.png',
                ['object'] = 'prop_gc_chair02',
                ['price'] = 90,
                ['label'] = 'Sheet metal chair',
                ['description'] = 'Reddish silver sheet metal chair, it is old but it is pretty.',
                ['colorlabel'] = 'Metal',
                ['colors'] = {}
            },
            [26] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_off_chair_04b.png',
                ['object'] = 'prop_off_chair_04b',
                ['price'] = 150,
                ['label'] = 'Office chair',
                ['description'] = 'Small office chair, its nice but its not for XL people, you know what I mean...',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Gray',
                        object = 'prop_off_chair_04_s',
                        price = 150
                    },
                    {
                        label = 'Blue',
                        object = 'prop_off_chair_04',
                        price = 150
                    },
                    {
                        label = 'Small',
                        object = 'prop_off_chair_03',
                        price = 150
                    }
                }
            },
            [27] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_old_deck_chair.png',
                ['object'] = 'prop_old_deck_chair',
                ['price'] = 40,
                ['label'] = 'Beach chair',
                ['description'] = 'Beautiful beach chair with bright colors.',
                ['colorlabel'] = 'Open green',
                ['colors'] = {
                    {
                        label = 'Close green',
                        object = 'prop_old_deck_chair_02',
                        price = 40
                    }
                }
            },
            [28] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_old_wood_chair.png',
                ['object'] = 'prop_old_wood_chair',
                ['price'] = 55,
                ['label'] = 'Old Zombie chair',
                ['description'] = 'Old wooden chair, nothing special.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {
                    {
                        label = 'Old',
                        object = 'prop_rock_chair_01',
                        price = 40
                    }
                }
            },
            [29] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/v_corp_bk_chair3.png',
                ['object'] = 'v_corp_bk_chair3',
                ['price'] = 200,
                ['label'] = 'Barber chair',
                ['description'] = 'Black chair for barbershops, armchair style, magnificent and shiny.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [30] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/v_corp_cd_chair.png',
                ['object'] = 'v_corp_cd_chair',
                ['price'] = 100,
                ['label'] = 'Red simple chair',
                ['description'] = 'Corporate red chair, beautiful passion color.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [31] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/v_ilev_hd_chair.png',
                ['object'] = 'v_ilev_hd_chair',
                ['price'] = 150,
                ['label'] = 'Black square chair',
                ['description'] = 'A beautiful and large square armchair style chair looks so comfortable.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [32] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/v_res_m_l_chair1.png',
                ['object'] = 'v_res_m_l_chair1',
                ['price'] = 350,
                ['label'] = 'Antique wooden chair',
                ['description'] = 'An exclusive chair, beautiful with antique details, a definitely collectors chair.',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [33] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/v_ret_fh_chair01.png',
                ['object'] = 'v_ret_fh_chair01',
                ['price'] = 80,
                ['label'] = 'Polished wood chair',
                ['description'] = 'A beautiful and comfortable polished white wooden chair.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [34] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/xm_base_cia_chair_conf.png',
                ['object'] = 'xm_base_cia_chair_conf',
                ['price'] = 80,
                ['label'] = 'School wall chair',
                ['description'] = 'Ideal school chair to place on the wall.',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [35] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/xm_int_lev_sub_chair_01.png',
                ['object'] = 'xm_int_lev_sub_chair_01',
                ['price'] = 200,
                ['label'] = 'Fixed chair',
                ['description'] = 'Fixed chair ideal for hairdressers, it is a comfortable, wide and fixed chair.',
                ['colorlabel'] = 'Blue',
                ['colors'] = {}
            },
            [36] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/xm_lab_chairarm_02.png',
                ['object'] = 'xm_lab_chairarm_02',
                ['price'] = 120,
                ['label'] = 'Outdoor chair',
                ['description'] = 'Outdoor chair with elastic mattresses.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [37] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_table_06_chr.png',
                ['object'] = 'prop_table_06_chr',
                ['price'] = 170,
                ['label'] = 'Outdoor chair Deluxe',
                ['description'] = 'Ultra deluxe outdoor chair!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [38] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_table_08_chr.png',
                ['object'] = 'prop_table_08_chr',
                ['price'] = 250,
                ['label'] = 'Oak Bench',
                ['description'] = 'A long oak bench, ideal for outdoors or horror houses, boo?',
                ['colorlabel'] = 'Roble',
                ['colors'] = {}
            },
            [39] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_table_05_chr.png',
                ['object'] = 'prop_table_05_chr',
                ['price'] = 350,
                ['label'] = 'Relax chair',
                ['description'] = 'Relaxing outdoor chair, oh yeah bitches',
                ['colorlabel'] = 'Relax',
                ['colors'] = {}
            },
            [40] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_table_04_chr.png',
                ['object'] = 'prop_table_04_chr',
                ['price'] = 230,
                ['label'] = 'Beautiful white chair',
                ['description'] = 'A stainless and white metal chair, beautiful for indoors or outdoors',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [41] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_table_02_chr.png',
                ['object'] = 'prop_table_02_chr',
                ['price'] = 160,
                ['label'] = 'Pine Chair',
                ['description'] = 'A upholstered and varnished pine chair',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [42] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/chair/prop_yacht_table_01.png',
                ['object'] = 'prop_yacht_table_01',
                ['price'] = 80,
                ['label'] = 'Yatch plastic chair',
                ['description'] = 'Chair set for the Yatch collection',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [43] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/chair/hei_heist_stn_benchshort.png',
                ['object'] = 'hei_heist_stn_benchshort',
                ['price'] = 400,
                ['label'] = 'Burgershot bench',
                ['description'] = 'Bench for commercial areas',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            }
        }
    },
    ['cooker'] = {
        label = 'Cooker',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-hood-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-hood-blue.svg',
        css = {
            width = 3.5,
            top = 2.9,
            left = 2.9,
            zIndex = 10
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_chip_fryer.png',
                ['object'] = 'prop_chip_fryer',
                ['price'] = 1500,
                ['label'] = 'Big cooker hood',
                ['description'] = 'A huge extractor for high-quality kitchens',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                ['cooker'] = true
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_cooker_03.png',
                ['object'] = 'prop_cooker_03',
                ['price'] = 2500,
                ['label'] = 'Cooker without hood',
                ['description'] = 'Modern and large kitchen, this does not require smoke outlets',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                ['cooker'] = true
            }
        }
    },
    ['dishwasher'] = {
        label = 'Dishwasher',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-dishwasher-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-dishwasher-blue.svg',
        css = {
            width = 4.0,
            top = 6.28,
            left = 5.0,
            zIndex = 6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_rub_washer_01.png',
                ['object'] = 'prop_rub_washer_01',
                ['price'] = 250,
                ['label'] = 'Broken washing',
                ['description'] = 'Old and dirty washing machine, its cheap at least.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_01.png',
                ['object'] = 'prop_washer_01',
                ['price'] = 250,
                ['label'] = 'Old washing',
                ['description'] = 'Old and dirty washing machine, it is cheap at least, better than the previous one if it is...',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_02.png',
                ['object'] = 'prop_washer_02',
                ['price'] = 400,
                ['label'] = 'Clear washing',
                ['description'] = 'A beautiful washing machine, at a good price and completely new.',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/prop_washer_03.png',
                ['object'] = 'prop_washer_03',
                ['price'] = 460,
                ['label'] = 'Deluxe washing',
                ['description'] = 'The best washing machine on the market, it performs all washing and drying functions in minutes!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bathroom/items/washing/v_ret_fh_dryer.png',
                ['object'] = 'v_ret_fh_dryer',
                ['price'] = 360,
                ['label'] = 'Simple modern washing',
                ['description'] = 'A simple washing machine of good quality and modern, a luxury among the economical!',
                ['colorlabel'] = 'New',
                ['colors'] = {
                    {
                        label = 'Old',
                        object = 'v_ret_fh_washmach',
                        price = 310
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bathroom/items/washing/bkr_prop_prtmachine_dryer_spin.png',
                ['object'] = 'bkr_prop_prtmachine_dryer_spin',
                ['price'] = 1390,
                ['label'] = 'Money washing',
                ['description'] = 'They say Pablo Escobar laundered his money here.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['fridge'] = {
        label = 'Fridge',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-fridge-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-fridge-blue.svg',
        css = {
            width = 4.1,
            top = 2.25,
            left = 7.4,
            zIndex = 4
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/fridge/prop_bar_beerfridge_01.png',
                ['object'] = 'prop_bar_beerfridge_01',
                ['price'] = 250,
                ['label'] = 'Large Commercial refrigerator',
                ['description'] = 'A refrigerator for shops, you could fill it with drinks!',
                ['colorlabel'] = 'Alcohol',
                ['colors'] = {
                    {
                        label = 'Soft drinks',
                        object = 'prop_bar_fridge_01',
                        price = 220,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 50000,
                            slots = 5
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_bar_fridge_02.png',
                ['object'] = 'prop_bar_fridge_02',
                ['price'] = 180,
                ['label'] = 'Medium Commercial refrigerator',
                ['description'] = 'A refrigerator for shops, you could fill it with drinks!',
                ['colorlabel'] = 'Alcohol',
                ['colors'] = {
                    {
                        label = 'Soft drinks',
                        object = 'prop_bar_fridge_04',
                        price = 150,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 50000,
                            slots = 5
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_bar_fridge_03.png',
                ['object'] = 'prop_bar_fridge_03',
                ['price'] = 120,
                ['label'] = 'Small Commercial refrigerator',
                ['description'] = 'A refrigerator for shops, you could fill it with drinks!',
                ['colorlabel'] = 'Various drinks',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_fridge_01.png',
                ['object'] = 'prop_fridge_01',
                ['price'] = 400,
                ['label'] = 'Professional refrigerator',
                ['description'] = 'A huge refrigerator for professionals, the best quality.',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_fridge_03.png',
                ['object'] = 'prop_fridge_03',
                ['price'] = 290,
                ['label'] = 'Home refrigerator',
                ['description'] = 'A simple refrigerator for the home with a freezer.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_trailr_fridge.png',
                ['object'] = 'prop_trailr_fridge',
                ['price'] = 200,
                ['label'] = 'Old home refrigerator',
                ['description'] = 'Old home refrigerator, still works but has some damage.',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/prop_vend_fridge01.png',
                ['object'] = 'prop_vend_fridge01',
                ['price'] = 330,
                ['label'] = 'Cola refrigerator',
                ['description'] = 'Commercial Cola refrigerator, the best drinks in Los Santos!',
                ['colorlabel'] = 'Cola',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/v_res_fridgemoda.png',
                ['object'] = 'v_res_fridgemoda',
                ['price'] = 750,
                ['label'] = 'Quality refrigerator',
                ['description'] = 'Huge commercial refrigerator, made for restaurants or large businesses',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'v_res_fridgemodsml',
                        price = 550,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 50000,
                            slots = 5
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/v_res_tre_fridge.png',
                ['object'] = 'v_res_tre_fridge',
                ['price'] = 650,
                ['label'] = 'Designer refrigerator',
                ['description'] = 'A beautiful rustic refrigerator, designed for a stylish home.',
                ['colorlabel'] = 'Green',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/fridge/v_ret_ml_fridge.png',
                ['object'] = 'v_ret_ml_fridge',
                ['price'] = 330,
                ['label'] = 'Retail fridge',
                ['description'] = 'A retail fridge, includes some drinks!',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            }
        }
    },
    ['hangingcaninets'] = {
        label = 'Hanging Caninets',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-upshelf-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-upshelf-blue.svg',
        css = {
            width = 3.5,
            top = 2.6,
            left = 5.4,
            zIndex = 6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_06.png',
                ['object'] = 'apa_mp_h_str_sideboardl_06',
                ['price'] = 620,
                ['label'] = 'Elegants Chest',
                ['description'] = 'Beautiful modern sideboard, with minimalist white details',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboardm_03',
                        price = 560
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/ex_prop_ex_toolchest_01.png',
                ['object'] = 'ex_prop_ex_toolchest_01',
                ['price'] = 520,
                ['label'] = 'Mechanic chest',
                ['description'] = 'Sideboard for mechanics, the best on the market with red details. It has multiple types of measurements.',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'gr_prop_gr_tool_draw_01a',
                        price = 350,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Medium',
                        object = 'gr_prop_gr_tool_draw_01b',
                        price = 420,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Big',
                        object = 'gr_prop_gr_tool_draw_01d',
                        price = 480,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Box',
                        object = 'gr_prop_gr_tool_chest_01a',
                        price = 250,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_bed_chestdrawer_02.png',
                ['object'] = 'apa_mp_h_bed_chestdrawer_02',
                ['price'] = 330,
                ['label'] = 'Sideboard Chest',
                ['description'] = 'Beautiful purple desk with yellow details.',
                ['colorlabel'] = 'Purple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_14.png',
                ['object'] = 'apa_mp_h_str_sideboardl_14',
                ['price'] = 350,
                ['label'] = 'Sideboard Shiny Wood',
                ['description'] = 'A wooden piece of furniture with details in brown colors, beautiful',
                ['colorlabel'] = 'Wood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_13.png',
                ['object'] = 'apa_mp_h_str_sideboardl_13',
                ['price'] = 450,
                ['label'] = 'Sideboard Dynamic',
                ['description'] = 'A huge sideboard with gray details, ultra minimalist and at a juicy price, what are you waiting for?',
                ['colorlabel'] = 'White with details',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardm_02.png',
                ['object'] = 'apa_mp_h_str_sideboardm_02',
                ['price'] = 450,
                ['label'] = 'Sideboard Pinewood',
                ['description'] = 'Beautiful Pinewood sideboard table',
                ['colorlabel'] = 'Pinewood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_bed_chestdrawer_04.png',
                ['object'] = 'hei_heist_bed_chestdrawer_04',
                ['price'] = 450,
                ['label'] = 'Small Varnished Sidebar',
                ['description'] = 'Norwegian style varnished sidebar',
                ['colorlabel'] = 'Varnished',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_04.png',
                ['object'] = 'hei_heist_str_sideboardl_04',
                ['price'] = 550,
                ['label'] = 'Sideboard Blue',
                ['description'] = 'Classic movie blue sidebar',
                ['colorlabel'] = 'Blue',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_02.png',
                ['object'] = 'hei_heist_str_sideboardl_02',
                ['price'] = 250,
                ['label'] = 'Sideboard Beige',
                ['description'] = 'Beige sidebar with beautiful details and high legs',
                ['colorlabel'] = 'Beige',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/p_v_43_safe_s.png',
                ['object'] = 'p_v_43_safe_s',
                ['price'] = 750,
                ['label'] = 'Safe',
                ['description'] = 'Super secure safe, where did Pablo Escobar hide his money?',
                ['colorlabel'] = 'Green',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_05.png',
                ['object'] = 'hei_heist_str_sideboardl_05',
                ['price'] = 650,
                ['label'] = 'Sideboard Retail ',
                ['description'] = 'Sideboard for retail people, with white and blue details, very good by the way',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_03.png',
                ['object'] = 'hei_heist_str_sideboardl_03',
                ['price'] = 550,
                ['label'] = 'Sideboard Wood',
                ['description'] = 'Beautiful solid wooden sideboard, harder than Transformer',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_11.png',
                ['object'] = 'apa_mp_h_str_sideboardl_11',
                ['price'] = 850,
                ['label'] = 'Sideboard Wood Modern',
                ['description'] = 'Beautiful solid wooden sideboard, harder than a turtle sandwich',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_09.png',
                ['object'] = 'apa_mp_h_str_sideboardl_09',
                ['price'] = 550,
                ['label'] = 'Sideboard Simple',
                ['description'] = 'Theres not much to say, its horrible...',
                ['colorlabel'] = 'Simple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            }
        }
    },
    ['hotplate'] = {
        label = 'Hotplate',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-burners-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-burners-blue.svg',
        css = {
            width = 3.0,
            top = 6.8,
            left = 3.25,
            zIndex = 9
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_chip_fryer.png',
                ['object'] = 'prop_chip_fryer',
                ['price'] = 1500,
                ['label'] = 'Big cooker hood',
                ['description'] = 'A huge extractor for high-quality kitchens',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_cooker_03.png',
                ['object'] = 'prop_cooker_03',
                ['price'] = 2500,
                ['label'] = 'Cooker without hood',
                ['description'] = 'Modern and large kitchen, this does not require smoke outlets',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['kitchenetteleft'] = {
        label = 'Kitchenette Left',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-counter2-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-counter2-blue.svg',
        css = {
            width = 7.4,
            top = 5.5,
            left = 9.9
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_06.png',
                ['object'] = 'apa_mp_h_str_sideboardl_06',
                ['price'] = 620,
                ['label'] = 'Elegants Chest',
                ['description'] = 'Beautiful modern sideboard, with minimalist white details',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboardm_03',
                        price = 560
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/ex_prop_ex_toolchest_01.png',
                ['object'] = 'ex_prop_ex_toolchest_01',
                ['price'] = 520,
                ['label'] = 'Mechanic chest',
                ['description'] = 'Sideboard for mechanics, the best on the market with red details. It has multiple types of measurements.',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'gr_prop_gr_tool_draw_01a',
                        price = 350,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Medium',
                        object = 'gr_prop_gr_tool_draw_01b',
                        price = 420,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Big',
                        object = 'gr_prop_gr_tool_draw_01d',
                        price = 480,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Box',
                        object = 'gr_prop_gr_tool_chest_01a',
                        price = 250,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_bed_chestdrawer_02.png',
                ['object'] = 'apa_mp_h_bed_chestdrawer_02',
                ['price'] = 330,
                ['label'] = 'Sideboard Chest',
                ['description'] = 'Beautiful purple desk with yellow details.',
                ['colorlabel'] = 'Purple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_14.png',
                ['object'] = 'apa_mp_h_str_sideboardl_14',
                ['price'] = 350,
                ['label'] = 'Sideboard Shiny Wood',
                ['description'] = 'A wooden piece of furniture with details in brown colors, beautiful',
                ['colorlabel'] = 'Wood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_13.png',
                ['object'] = 'apa_mp_h_str_sideboardl_13',
                ['price'] = 450,
                ['label'] = 'Sideboard Dynamic',
                ['description'] = 'A huge sideboard with gray details, ultra minimalist and at a juicy price, what are you waiting for?',
                ['colorlabel'] = 'White with details',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardm_02.png',
                ['object'] = 'apa_mp_h_str_sideboardm_02',
                ['price'] = 450,
                ['label'] = 'Sideboard Pinewood',
                ['description'] = 'Beautiful Pinewood sideboard table',
                ['colorlabel'] = 'Pinewood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_bed_chestdrawer_04.png',
                ['object'] = 'hei_heist_bed_chestdrawer_04',
                ['price'] = 450,
                ['label'] = 'Small Varnished Sidebar',
                ['description'] = 'Norwegian style varnished sidebar',
                ['colorlabel'] = 'Varnished',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_04.png',
                ['object'] = 'hei_heist_str_sideboardl_04',
                ['price'] = 550,
                ['label'] = 'Sideboard Blue',
                ['description'] = 'Classic movie blue sidebar',
                ['colorlabel'] = 'Blue',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_02.png',
                ['object'] = 'hei_heist_str_sideboardl_02',
                ['price'] = 250,
                ['label'] = 'Sideboard Beige',
                ['description'] = 'Beige sidebar with beautiful details and high legs',
                ['colorlabel'] = 'Beige',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/p_v_43_safe_s.png',
                ['object'] = 'p_v_43_safe_s',
                ['price'] = 750,
                ['label'] = 'Safe',
                ['description'] = 'Super secure safe, where did Pablo Escobar hide his money?',
                ['colorlabel'] = 'Green',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_05.png',
                ['object'] = 'hei_heist_str_sideboardl_05',
                ['price'] = 650,
                ['label'] = 'Sideboard Retail ',
                ['description'] = 'Sideboard for retail people, with white and blue details, very good by the way',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_03.png',
                ['object'] = 'hei_heist_str_sideboardl_03',
                ['price'] = 550,
                ['label'] = 'Sideboard Wood',
                ['description'] = 'Beautiful solid wooden sideboard, harder than Transformer',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_11.png',
                ['object'] = 'apa_mp_h_str_sideboardl_11',
                ['price'] = 850,
                ['label'] = 'Sideboard Wood Modern',
                ['description'] = 'Beautiful solid wooden sideboard, harder than a turtle sandwich',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_09.png',
                ['object'] = 'apa_mp_h_str_sideboardl_09',
                ['price'] = 550,
                ['label'] = 'Sideboard Simple',
                ['description'] = 'Theres not much to say, its horrible...',
                ['colorlabel'] = 'Simple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            }
        }
    },
    ['kitchenetteright'] = {
        label = 'Kitchenette Right',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-counter1-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-counter1-blue.svg',
        css = {
            width = 6.0,
            top = 5.8,
            left = 15.0,
            zIndex = 1
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_06.png',
                ['object'] = 'apa_mp_h_str_sideboardl_06',
                ['price'] = 620,
                ['label'] = 'Elegants Chest',
                ['description'] = 'Beautiful modern sideboard, with minimalist white details',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboardm_03',
                        price = 560
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/ex_prop_ex_toolchest_01.png',
                ['object'] = 'ex_prop_ex_toolchest_01',
                ['price'] = 520,
                ['label'] = 'Mechanic chest',
                ['description'] = 'Sideboard for mechanics, the best on the market with red details. It has multiple types of measurements.',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'gr_prop_gr_tool_draw_01a',
                        price = 350,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Medium',
                        object = 'gr_prop_gr_tool_draw_01b',
                        price = 420,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Big',
                        object = 'gr_prop_gr_tool_draw_01d',
                        price = 480,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Box',
                        object = 'gr_prop_gr_tool_chest_01a',
                        price = 250,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_bed_chestdrawer_02.png',
                ['object'] = 'apa_mp_h_bed_chestdrawer_02',
                ['price'] = 330,
                ['label'] = 'Sideboard Chest',
                ['description'] = 'Beautiful purple desk with yellow details.',
                ['colorlabel'] = 'Purple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_14.png',
                ['object'] = 'apa_mp_h_str_sideboardl_14',
                ['price'] = 350,
                ['label'] = 'Sideboard Shiny Wood',
                ['description'] = 'A wooden piece of furniture with details in brown colors, beautiful',
                ['colorlabel'] = 'Wood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_13.png',
                ['object'] = 'apa_mp_h_str_sideboardl_13',
                ['price'] = 450,
                ['label'] = 'Sideboard Dynamic',
                ['description'] = 'A huge sideboard with gray details, ultra minimalist and at a juicy price, what are you waiting for?',
                ['colorlabel'] = 'White with details',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardm_02.png',
                ['object'] = 'apa_mp_h_str_sideboardm_02',
                ['price'] = 450,
                ['label'] = 'Sideboard Pinewood',
                ['description'] = 'Beautiful Pinewood sideboard table',
                ['colorlabel'] = 'Pinewood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_bed_chestdrawer_04.png',
                ['object'] = 'hei_heist_bed_chestdrawer_04',
                ['price'] = 450,
                ['label'] = 'Small Varnished Sidebar',
                ['description'] = 'Norwegian style varnished sidebar',
                ['colorlabel'] = 'Varnished',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_04.png',
                ['object'] = 'hei_heist_str_sideboardl_04',
                ['price'] = 550,
                ['label'] = 'Sideboard Blue',
                ['description'] = 'Classic movie blue sidebar',
                ['colorlabel'] = 'Blue',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_02.png',
                ['object'] = 'hei_heist_str_sideboardl_02',
                ['price'] = 250,
                ['label'] = 'Sideboard Beige',
                ['description'] = 'Beige sidebar with beautiful details and high legs',
                ['colorlabel'] = 'Beige',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/p_v_43_safe_s.png',
                ['object'] = 'p_v_43_safe_s',
                ['price'] = 750,
                ['label'] = 'Safe',
                ['description'] = 'Super secure safe, where did Pablo Escobar hide his money?',
                ['colorlabel'] = 'Green',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_05.png',
                ['object'] = 'hei_heist_str_sideboardl_05',
                ['price'] = 650,
                ['label'] = 'Sideboard Retail ',
                ['description'] = 'Sideboard for retail people, with white and blue details, very good by the way',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_03.png',
                ['object'] = 'hei_heist_str_sideboardl_03',
                ['price'] = 550,
                ['label'] = 'Sideboard Wood',
                ['description'] = 'Beautiful solid wooden sideboard, harder than Transformer',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_11.png',
                ['object'] = 'apa_mp_h_str_sideboardl_11',
                ['price'] = 850,
                ['label'] = 'Sideboard Wood Modern',
                ['description'] = 'Beautiful solid wooden sideboard, harder than a turtle sandwich',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_09.png',
                ['object'] = 'apa_mp_h_str_sideboardl_09',
                ['price'] = 550,
                ['label'] = 'Sideboard Simple',
                ['description'] = 'Theres not much to say, its horrible...',
                ['colorlabel'] = 'Simple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            }
        }
    },
    ['knifeblockset'] = {
        label = 'Knife Block Set',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-knives-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-knives-blue.svg',
        css = {
            width = 1.5,
            top = 4.2,
            left = 14.3,
            zIndex = 1
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/knifes/prop_cs_bowie_knife.png',
                ['object'] = 'prop_cs_bowie_knife',
                ['price'] = 1590,
                ['label'] = 'Cutucuchillo',
                ['description'] = 'Captain Blackbeard fought with this knife in Pirates of the Caribbean, thats why its value',
                ['colorlabel'] = 'Blackbeard',
                ['colors'] = {
                    {
                        label = 'The same one, I think?',
                        object = 'prop_knife',
                        price = 1590
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/knifes/v_res_mknifeblock.png',
                ['object'] = 'v_res_mknifeblock',
                ['price'] = 150,
                ['label'] = 'Knife Stand',
                ['description'] = 'Beautiful knife stand in various colors',
                ['colorlabel'] = 'Wood',
                ['colors'] = {
                    {
                        label = 'Black',
                        object = 'prop_knife_stand',
                        price = 150
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/knifes/prop_w_me_knife_01.png',
                ['object'] = 'prop_w_me_knife_01',
                ['price'] = 120,
                ['label'] = 'Kiwi Knife',
                ['description'] = 'Knife that Kiwi will use to murder anyone who opens a ticket',
                ['colorlabel'] = 'Red',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/knifes/v_res_mkniferack.png',
                ['object'] = 'v_res_mkniferack',
                ['price'] = 220,
                ['label'] = 'Wall knives',
                ['description'] = 'Professional Wall Knife Set',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['microwave'] = {
        label = 'Microwave',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-microwave-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-microwave-blue.svg',
        css = {
            width = 3.3,
            top = 4.6,
            left = 10.60,
            zIndex = 3
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/microwave/prop_microwave_1.png',
                ['object'] = 'prop_microwave_1',
                ['price'] = 250,
                ['label'] = 'Microwave Horrible ',
                ['description'] = 'Horrible microwave, it honestly looks used, but its new, I swear',
                ['colorlabel'] = 'Beige',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/microwave/prop_micro_01.png',
                ['object'] = 'prop_micro_01',
                ['price'] = 400,
                ['label'] = 'Microwave Pretty',
                ['description'] = 'A beautiful microwave, with this you can heat your food!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/microwave/prop_micro_02.png',
                ['object'] = 'prop_micro_02',
                ['price'] = 650,
                ['label'] = 'Microwave Digital',
                ['description'] = 'A beautiful microwave, with this you can heat your food, but this time with digital',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['oven'] = {
        label = 'Oven',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-oven-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-oven-blue.svg',
        css = {
            width = 4.0,
            top = 6.25,
            left = 2.7,
            zIndex = 7
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_chip_fryer.png',
                ['object'] = 'prop_chip_fryer',
                ['price'] = 1500,
                ['label'] = 'Big cooker hood',
                ['description'] = 'A huge extractor for high-quality kitchens',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/cooker/prop_cooker_03.png',
                ['object'] = 'prop_cooker_03',
                ['price'] = 2500,
                ['label'] = 'Cooker without hood',
                ['description'] = 'Modern and large kitchen, this does not require smoke outlets',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            }
        }
    },
    ['sink'] = {
        label = 'Sink',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-sink-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-sink-blue.svg',
        css = {
            width = 3.5,
            top = 4.9,
            left = 15.8,
            zIndex = 5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/sink/prop_bar_sink_01.png',
                ['object'] = 'prop_bar_sink_01',
                ['price'] = 380,
                ['label'] = 'Name for Prop',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Wall',
                sink = {
                    ptfxOffset = vec3(0.0, 0.0, 0.0)
                },
                ['colors'] = {
                    {
                        label = 'Floor',
                        object = 'prop_ff_sink_02',
                        price = 380
                    },
                    {
                        label = 'Advanced',
                        object = 'prop_sink_04',
                        price = 820
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/sink/prop_sink_02.png',
                ['object'] = 'prop_sink_02',
                ['price'] = 350,
                ['label'] = 'Name for Prop',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Single',
                sink = {
                    ptfxOffset = vec3(0.0, -0.2, 0.3)
                },
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'prop_ff_sink_02',
                        price = 380
                    },
                    {
                        label = 'Stone',
                        object = 'prop_sink_04',
                        price = 680
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/sink/prop_sink_06.png',
                ['object'] = 'prop_sink_06',
                ['price'] = 0,
                ['label'] = 'Name for Prop',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/sink/v_res_mbsink.png',
                ['object'] = 'v_res_mbsink',
                ['price'] = 0,
                ['label'] = 'Name for Prop',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/sink/v_ilev_mm_faucet.png',
                ['object'] = 'v_ilev_mm_faucet',
                ['price'] = 0,
                ['label'] = 'Name for Prop',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            }
        }
    },
    ['table'] = {
        label = 'Table',
        img = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-table-blue.svg',
        navigation = 1,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/kitchen/kitchen-table-blue.svg',
        css = {
            width = 8.5,
            top = 6.7,
            left = 14.7,
            zIndex = 2
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_01.png',
                ['object'] = 'apa_mp_h_din_table_01',
                ['price'] = 550,
                ['label'] = 'Modern Glass Table',
                ['description'] = 'A modern and beautiful glass table, a little expensive, but worth it',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_04.png',
                ['object'] = 'apa_mp_h_din_table_04',
                ['price'] = 420,
                ['label'] = 'Single Glass Table',
                ['description'] = 'Beautiful metal and glass table',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_06.png',
                ['object'] = 'apa_mp_h_din_table_06',
                ['price'] = 210,
                ['label'] = 'Modern Plastic Table',
                ['description'] = 'A beautiful modern plastic and metal table, good price by the way...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_01.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_01',
                ['price'] = 190,
                ['label'] = 'Coffee Table',
                ['description'] = 'This is where Prince Quasar drank his coffee, did you know that? Me neither, but it says so on the label haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_02.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_02',
                ['price'] = 330,
                ['label'] = 'Yatch Coffee Table',
                ['description'] = 'This coffee table is suitable for yacht trips, the truth is it is very hard and robust, beautiful, right?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_side_table_01.png',
                ['object'] = 'apa_mp_h_yacht_side_table_01',
                ['price'] = 90,
                ['label'] = 'Mini Coffee Table',
                ['description'] = 'Small coffee table, in a studio apartment it would look perfect, it takes up almost no space',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_ven_market_table1.png',
                ['object'] = 'prop_ven_market_table1',
                ['price'] = 150,
                ['label'] = 'Exterior table',
                ['description'] = 'Simple and beautiful outdoor table',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_yacht_table_03.png',
                ['object'] = 'prop_yacht_table_03',
                ['price'] = 400,
                ['label'] = 'Yatch plastic table',
                ['description'] = 'High density plastic yacht table set',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Medium',
                        object = 'prop_yacht_table_02',
                        price = 250
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/v_ret_fh_dinetable.png',
                ['object'] = 'v_ret_fh_dinetable',
                ['price'] = 830,
                ['label'] = 'Horror table',
                ['description'] = 'Above this table I think Frankenstain autopsy was done haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_07.png',
                ['object'] = 'hei_heist_din_table_07',
                ['price'] = 1200,
                ['label'] = 'Glass deluxe table',
                ['description'] = 'A beautiful and rounded glass table with a deluxe style and high quality',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_04.png',
                ['object'] = 'hei_heist_din_table_04',
                ['price'] = 500,
                ['label'] = 'Quartz crystal',
                ['description'] = 'Precious quartz crystal table',
                ['colorlabel'] = 'Crystal',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboards_02',
                        price = 300
                    }
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_06.png',
                ['object'] = 'hei_heist_din_table_06',
                ['price'] = 600,
                ['label'] = 'Familiar table',
                ['description'] = 'A huge table and chairs set for the whole family',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_fbi3_coffee_table.png',
                ['object'] = 'prop_fbi3_coffee_table',
                ['price'] = 300,
                ['label'] = 'Modern coffee table',
                ['description'] = 'Low coffee table, beautiful and delicious, ah no, you cant eat that haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_01.png',
                ['object'] = 'prop_table_01',
                ['price'] = 200,
                ['label'] = 'Pino table 01',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_02.png',
                ['object'] = 'prop_table_02',
                ['price'] = 250,
                ['label'] = 'Pino table 02',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_04.png',
                ['object'] = 'prop_table_04',
                ['price'] = 320,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_05.png',
                ['object'] = 'prop_table_05',
                ['price'] = 360,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidesml_01.png',
                ['object'] = 'apa_mp_h_tab_sidesml_01',
                ['price'] = 350,
                ['label'] = 'Small kit tables',
                ['description'] = 'An economical kit of tables for your home',
                ['colorlabel'] = 'Kit',
                ['colors'] = {
                    {
                        label = 'Single',
                        object = 'apa_mp_h_tab_sidesml_02',
                        price = 50
                    }
                }
            },
            [19] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidelrg_02.png',
                ['object'] = 'apa_mp_h_tab_sidelrg_02',
                ['price'] = 760,
                ['label'] = 'Designer glass table',
                ['description'] = 'A beautiful glass table with a modern, artistic design.',
                ['colorlabel'] = 'Glass',
                ['colors'] = {
                    {
                        label = 'Economic',
                        object = 'apa_mp_h_tab_sidelrg_01',
                        price = 560
                    }
                }
            },
            [20] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/bkr_prop_fakeid_table.png',
                ['object'] = 'bkr_prop_fakeid_table',
                ['price'] = 110,
                ['label'] = 'Small Table',
                ['description'] = 'Small light table that still serves to eat, foldable and takes up almost no space',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [21] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_weed_table_01b.png',
                ['object'] = 'bkr_prop_weed_table_01b',
                ['price'] = 150,
                ['label'] = 'Folding table',
                ['description'] = 'A folding table, dont look at the other options, are they somewhat... illegal?',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Weed',
                        object = 'bkr_prop_weed_table_01a',
                        price = 800
                    },
                    {
                        label = 'Chemicals',
                        object = 'bkr_prop_meth_table01a',
                        price = 1250
                    }
                }
            },
            [22] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_06.png',
                ['object'] = 'prop_table_06',
                ['price'] = 350,
                ['label'] = 'Garden Table',
                ['description'] = 'An ideal outdoor table for your garden!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [23] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_08.png',
                ['object'] = 'prop_table_08',
                ['price'] = 250,
                ['label'] = 'Picnic Table',
                ['description'] = 'Oak table for outdoors or horror houses, you know, boo!',
                ['colorlabel'] = 'Roble',
                ['colors'] = {}
            },
            [24] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_07.png',
                ['object'] = 'prop_table_07',
                ['price'] = 125,
                ['label'] = 'Mini bar table',
                ['description'] = 'Ideal for bars or cafes!',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [25] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_01.png',
                ['object'] = 'prop_table_para_comb_01',
                ['price'] = 600,
                ['label'] = 'Table with pergola',
                ['description'] = 'Collection of tables with pergolas, beautiful!',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'prop_table_para_comb_03',
                        price = 600
                    },
                    {
                        label = 'White',
                        object = 'prop_table_para_comb_04',
                        price = 600
                    }
                }
            },
            [26] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_02.png',
                ['object'] = 'prop_table_para_comb_02',
                ['price'] = 550,
                ['label'] = 'Single Table whit pergola',
                ['description'] = 'This outdoor pergola table is ideal for simple shops or kiosks',
                ['colorlabel'] = 'Plastic',
                ['colors'] = {
                    {
                        label = 'Roble',
                        object = 'prop_table_para_comb_05',
                        price = 650
                    }
                }
            },
            [27] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tablesmall_01.png',
                ['object'] = 'prop_tablesmall_01',
                ['price'] = 430,
                ['label'] = 'Small tea table',
                ['description'] = 'Low table, living room size to have tea while watching a nice movie on Netflix',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [28] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_tennis.png',
                ['object'] = 'prop_table_tennis',
                ['price'] = 1300,
                ['label'] = 'Tenis table',
                ['description'] = 'Beautiful, huge pingpong table but does not include rackets',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Rackets',
                        object = 'prop_table_ten_bat',
                        price = 25
                    }
                }
            },
            [29] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_pooltable_02.png',
                ['object'] = 'prop_pooltable_02',
                ['price'] = 3500,
                ['label'] = 'Pool table',
                ['description'] = 'Huge and expensive pool table, very expensive',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Purple',
                        object = 'prop_pooltable_3b',
                        price = 3700
                    }
                }
            },
            [30] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tri_table_01.png',
                ['object'] = 'prop_tri_table_01',
                ['price'] = 250,
                ['label'] = 'Voting table',
                ['description'] = 'Presidential voting table, yeah exactly...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [31] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/ex_mp_h_din_table_05.png',
                ['object'] = 'ex_mp_h_din_table_05',
                ['price'] = 430,
                ['label'] = 'Normal Table',
                ['description'] = 'A huge but quite simple table, it is widely used in offices',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [32] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_coffee_08.png',
                ['object'] = 'apa_mp_h_tab_coffee_08',
                ['price'] = 550,
                ['label'] = 'Modern Coffee Table',
                ['description'] = 'A very modern coffee table!',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [33] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/ex_prop_ex_console_table_01.png',
                ['object'] = 'ex_prop_ex_console_table_01',
                ['price'] = 550,
                ['label'] = 'Wifi Table',
                ['description'] = 'A very old coffee table, it looks like grandma',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [34] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_coke_pallet_01a.png',
                ['object'] = 'bkr_prop_coke_pallet_01a',
                ['price'] = 20,
                ['label'] = '"Table" for the poor',
                ['description'] = 'If you dont have much money... go ahead buddy haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            }
        }
    },
    ['pc-table'] = {
        label = 'PC Tables',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-desk-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-desk-blue.svg',
        css = {
            width = 5.0,
            top = 6.4,
            left = 16.4,
            zIndex = 7
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_01.png',
                ['object'] = 'apa_mp_h_din_table_01',
                ['price'] = 550,
                ['label'] = 'Modern Glass Table',
                ['description'] = 'A modern and beautiful glass table, a little expensive, but worth it',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_04.png',
                ['object'] = 'apa_mp_h_din_table_04',
                ['price'] = 420,
                ['label'] = 'Single Glass Table',
                ['description'] = 'Beautiful metal and glass table',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_06.png',
                ['object'] = 'apa_mp_h_din_table_06',
                ['price'] = 210,
                ['label'] = 'Modern Plastic Table',
                ['description'] = 'A beautiful modern plastic and metal table, good price by the way...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_01.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_01',
                ['price'] = 190,
                ['label'] = 'Coffee Table',
                ['description'] = 'This is where Prince Quasar drank his coffee, did you know that? Me neither, but it says so on the label haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_02.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_02',
                ['price'] = 330,
                ['label'] = 'Yatch Coffee Table',
                ['description'] = 'This coffee table is suitable for yacht trips, the truth is it is very hard and robust, beautiful, right?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_side_table_01.png',
                ['object'] = 'apa_mp_h_yacht_side_table_01',
                ['price'] = 90,
                ['label'] = 'Mini Coffee Table',
                ['description'] = 'Small coffee table, in a studio apartment it would look perfect, it takes up almost no space',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_ven_market_table1.png',
                ['object'] = 'prop_ven_market_table1',
                ['price'] = 150,
                ['label'] = 'Exterior table',
                ['description'] = 'Simple and beautiful outdoor table',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_yacht_table_03.png',
                ['object'] = 'prop_yacht_table_03',
                ['price'] = 400,
                ['label'] = 'Yatch plastic table',
                ['description'] = 'High density plastic yacht table set',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Medium',
                        object = 'prop_yacht_table_02',
                        price = 250
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/v_ret_fh_dinetable.png',
                ['object'] = 'v_ret_fh_dinetable',
                ['price'] = 830,
                ['label'] = 'Horror table',
                ['description'] = 'Above this table I think Frankenstain autopsy was done haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_07.png',
                ['object'] = 'hei_heist_din_table_07',
                ['price'] = 1200,
                ['label'] = 'Glass deluxe table',
                ['description'] = 'A beautiful and rounded glass table with a deluxe style and high quality',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_04.png',
                ['object'] = 'hei_heist_din_table_04',
                ['price'] = 500,
                ['label'] = 'Quartz crystal',
                ['description'] = 'Precious quartz crystal table',
                ['colorlabel'] = 'Crystal',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboards_02',
                        price = 300
                    }
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_06.png',
                ['object'] = 'hei_heist_din_table_06',
                ['price'] = 600,
                ['label'] = 'Familiar table',
                ['description'] = 'A huge table and chairs set for the whole family',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_fbi3_coffee_table.png',
                ['object'] = 'prop_fbi3_coffee_table',
                ['price'] = 300,
                ['label'] = 'Modern coffee table',
                ['description'] = 'Low coffee table, beautiful and delicious, ah no, you cant eat that haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_01.png',
                ['object'] = 'prop_table_01',
                ['price'] = 200,
                ['label'] = 'Pino table 01',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_02.png',
                ['object'] = 'prop_table_02',
                ['price'] = 250,
                ['label'] = 'Pino table 02',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_04.png',
                ['object'] = 'prop_table_04',
                ['price'] = 320,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_05.png',
                ['object'] = 'prop_table_05',
                ['price'] = 360,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidesml_01.png',
                ['object'] = 'apa_mp_h_tab_sidesml_01',
                ['price'] = 350,
                ['label'] = 'Small kit tables',
                ['description'] = 'An economical kit of tables for your home',
                ['colorlabel'] = 'Kit',
                ['colors'] = {
                    {
                        label = 'Single',
                        object = 'apa_mp_h_tab_sidesml_02',
                        price = 50
                    }
                }
            },
            [19] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidelrg_02.png',
                ['object'] = 'apa_mp_h_tab_sidelrg_02',
                ['price'] = 760,
                ['label'] = 'Designer glass table',
                ['description'] = 'A beautiful glass table with a modern, artistic design.',
                ['colorlabel'] = 'Glass',
                ['colors'] = {
                    {
                        label = 'Economic',
                        object = 'apa_mp_h_tab_sidelrg_01',
                        price = 560
                    }
                }
            },
            [20] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/bkr_prop_fakeid_table.png',
                ['object'] = 'bkr_prop_fakeid_table',
                ['price'] = 110,
                ['label'] = 'Small Table',
                ['description'] = 'Small light table that still serves to eat, foldable and takes up almost no space',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [21] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_weed_table_01b.png',
                ['object'] = 'bkr_prop_weed_table_01b',
                ['price'] = 150,
                ['label'] = 'Folding table',
                ['description'] = 'A folding table, dont look at the other options, are they somewhat... illegal?',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Weed',
                        object = 'bkr_prop_weed_table_01a',
                        price = 800
                    },
                    {
                        label = 'Chemicals',
                        object = 'bkr_prop_meth_table01a',
                        price = 1250
                    }
                }
            },
            [22] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_06.png',
                ['object'] = 'prop_table_06',
                ['price'] = 350,
                ['label'] = 'Garden Table',
                ['description'] = 'An ideal outdoor table for your garden!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [23] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_08.png',
                ['object'] = 'prop_table_08',
                ['price'] = 250,
                ['label'] = 'Picnic Table',
                ['description'] = 'Oak table for outdoors or horror houses, you know, boo!',
                ['colorlabel'] = 'Roble',
                ['colors'] = {}
            },
            [24] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_07.png',
                ['object'] = 'prop_table_07',
                ['price'] = 125,
                ['label'] = 'Mini bar table',
                ['description'] = 'Ideal for bars or cafes!',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [25] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_01.png',
                ['object'] = 'prop_table_para_comb_01',
                ['price'] = 600,
                ['label'] = 'Table with pergola',
                ['description'] = 'Collection of tables with pergolas, beautiful!',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'prop_table_para_comb_03',
                        price = 600
                    },
                    {
                        label = 'White',
                        object = 'prop_table_para_comb_04',
                        price = 600
                    }
                }
            },
            [26] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_02.png',
                ['object'] = 'prop_table_para_comb_02',
                ['price'] = 550,
                ['label'] = 'Single Table whit pergola',
                ['description'] = 'This outdoor pergola table is ideal for simple shops or kiosks',
                ['colorlabel'] = 'Plastic',
                ['colors'] = {
                    {
                        label = 'Roble',
                        object = 'prop_table_para_comb_05',
                        price = 650
                    }
                }
            },
            [27] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tablesmall_01.png',
                ['object'] = 'prop_tablesmall_01',
                ['price'] = 430,
                ['label'] = 'Small tea table',
                ['description'] = 'Low table, living room size to have tea while watching a nice movie on Netflix',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [28] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_tennis.png',
                ['object'] = 'prop_table_tennis',
                ['price'] = 1300,
                ['label'] = 'Tenis table',
                ['description'] = 'Beautiful, huge pingpong table but does not include rackets',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Rackets',
                        object = 'prop_table_ten_bat',
                        price = 25
                    }
                }
            },
            [29] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_pooltable_02.png',
                ['object'] = 'prop_pooltable_02',
                ['price'] = 3500,
                ['label'] = 'Pool table',
                ['description'] = 'Huge and expensive pool table, very expensive',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Purple',
                        object = 'prop_pooltable_3b',
                        price = 3700
                    }
                }
            },
            [30] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tri_table_01.png',
                ['object'] = 'prop_tri_table_01',
                ['price'] = 250,
                ['label'] = 'Voting table',
                ['description'] = 'Presidential voting table, yeah exactly...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [31] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/ex_mp_h_din_table_05.png',
                ['object'] = 'ex_mp_h_din_table_05',
                ['price'] = 430,
                ['label'] = 'Normal Table',
                ['description'] = 'A huge but quite simple table, it is widely used in offices',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [32] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_coffee_08.png',
                ['object'] = 'apa_mp_h_tab_coffee_08',
                ['price'] = 550,
                ['label'] = 'Modern Coffee Table',
                ['description'] = 'A very modern coffee table!',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [33] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/ex_prop_ex_console_table_01.png',
                ['object'] = 'ex_prop_ex_console_table_01',
                ['price'] = 550,
                ['label'] = 'Wifi Table',
                ['description'] = 'A very old coffee table, it looks like grandma',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [34] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_coke_pallet_01a.png',
                ['object'] = 'bkr_prop_coke_pallet_01a',
                ['price'] = 20,
                ['label'] = '"Table" for the poor',
                ['description'] = 'If you dont have much money... go ahead buddy haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            }
        }
    },
    ['bed'] = {
        label = 'Bed',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-bed-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-bed-blue.svg',
        css = {
            width = 8.5,
            top = 4.3,
            left = 9.2,
            zIndex = 4
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_bed_double_08.png',
                ['object'] = 'apa_mp_h_bed_double_08',
                ['price'] = 790,
                ['label'] = 'Designer green bed',
                ['description'] = 'A minimalist design bed with a beautiful color',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Tables of light',
                        object = 'hei_heist_bed_table_dble_04',
                        price = 150
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_bed_double_09.png',
                ['object'] = 'apa_mp_h_bed_double_09',
                ['price'] = 575,
                ['label'] = 'Modern floating bed',
                ['description'] = 'A bed with rounded floating legs, a high quality bed',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_bed_wide_05.png',
                ['object'] = 'apa_mp_h_bed_wide_05',
                ['price'] = 520,
                ['label'] = 'Children red bed',
                ['description'] = 'A huge bed for well-behaved children',
                ['colorlabel'] = 'Red',
                ['colors'] = {
                    {
                        label = 'Tables of light',
                        object = 'apa_mp_h_bed_table_wide_12',
                        price = 150
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_bed_with_table_02.png',
                ['object'] = 'apa_mp_h_bed_with_table_02',
                ['price'] = 1105,
                ['label'] = 'Complete bedding set',
                ['description'] = 'An executive oak wood bed set, complete with headrest and drawers',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_yacht_bed_01.png',
                ['object'] = 'apa_mp_h_yacht_bed_01',
                ['price'] = 750,
                ['label'] = 'Luxurious Yacht Bed',
                ['description'] = 'A completely luxurious bed with a fluffy solid leather backrest',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/apa_mp_h_yacht_bed_02.png',
                ['object'] = 'apa_mp_h_yacht_bed_02',
                ['price'] = 2500,
                ['label'] = 'Super luxury black bed',
                ['description'] = 'The most luxurious bed on the market, a black bed with high-density mattresses, the best of the best!',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/bed/bkr_prop_biker_campbed_01.png',
                ['object'] = 'bkr_prop_biker_campbed_01',
                ['price'] = 200,
                ['label'] = 'Soldier stretcher',
                ['description'] = 'A soldier stretcher, ideal for trips to the forest?',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/ex_prop_exec_bed_01.png',
                ['object'] = 'ex_prop_exec_bed_01',
                ['price'] = 80,
                ['label'] = 'Poor bed',
                ['description'] = 'The poorest and simplest bed we have, I wont say anything, just look at it and judge for yourself haha',
                ['colorlabel'] = 'Dirty',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/gr_prop_bunker_bed_01.png',
                ['object'] = 'gr_prop_bunker_bed_01',
                ['price'] = 120,
                ['label'] = 'Extremely simple bed',
                ['description'] = 'A basic and simple, economical bed',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/p_lestersbed_s.png',
                ['object'] = 'p_lestersbed_s',
                ['price'] = 410,
                ['label'] = 'Wooden bed',
                ['description'] = 'A beautiful bedding set with a simple wooden mattress',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/p_mbbed_s.png',
                ['object'] = 'p_mbbed_s',
                ['price'] = 980,
                ['label'] = 'Royal bed',
                ['description'] = 'Only kings and queens sleep in this bed, get ready for a princely experience',
                ['colorlabel'] = 'Roble',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/bed/v_res_msonbed_s.png',
                ['object'] = 'v_res_msonbed_s',
                ['price'] = 600,
                ['label'] = 'Motel bed',
                ['description'] = 'A dark colored motel bed, its pretty but it looks used, right?',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            }
        }
    },
    ['bedsidetable'] = {
        label = 'Bedside Table',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-bedsitetable-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-bedsitetable-blue.svg',
        css = {
            width = 3.5,
            top = 6.2,
            left = 6.5,
            zIndex = 5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_06.png',
                ['object'] = 'apa_mp_h_str_sideboardl_06',
                ['price'] = 620,
                ['label'] = 'Elegants Chest',
                ['description'] = 'Beautiful modern sideboard, with minimalist white details',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboardm_03',
                        price = 560
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/ex_prop_ex_toolchest_01.png',
                ['object'] = 'ex_prop_ex_toolchest_01',
                ['price'] = 520,
                ['label'] = 'Mechanic chest',
                ['description'] = 'Sideboard for mechanics, the best on the market with red details. It has multiple types of measurements.',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'gr_prop_gr_tool_draw_01a',
                        price = 350,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Medium',
                        object = 'gr_prop_gr_tool_draw_01b',
                        price = 420,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Big',
                        object = 'gr_prop_gr_tool_draw_01d',
                        price = 480,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    },
                    {
                        label = 'Box',
                        object = 'gr_prop_gr_tool_chest_01a',
                        price = 250,
                        type = 'stash',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        },
                        stash = {
                            maxweight = 1000000,
                            slots = 10
                        }
                    }
                },
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_bed_chestdrawer_02.png',
                ['object'] = 'apa_mp_h_bed_chestdrawer_02',
                ['price'] = 330,
                ['label'] = 'Sideboard Chest',
                ['description'] = 'Beautiful purple desk with yellow details.',
                ['colorlabel'] = 'Purple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_14.png',
                ['object'] = 'apa_mp_h_str_sideboardl_14',
                ['price'] = 350,
                ['label'] = 'Sideboard Shiny Wood',
                ['description'] = 'A wooden piece of furniture with details in brown colors, beautiful',
                ['colorlabel'] = 'Wood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_13.png',
                ['object'] = 'apa_mp_h_str_sideboardl_13',
                ['price'] = 450,
                ['label'] = 'Sideboard Dynamic',
                ['description'] = 'A huge sideboard with gray details, ultra minimalist and at a juicy price, what are you waiting for?',
                ['colorlabel'] = 'White with details',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardm_02.png',
                ['object'] = 'apa_mp_h_str_sideboardm_02',
                ['price'] = 450,
                ['label'] = 'Sideboard Pinewood',
                ['description'] = 'Beautiful Pinewood sideboard table',
                ['colorlabel'] = 'Pinewood',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_bed_chestdrawer_04.png',
                ['object'] = 'hei_heist_bed_chestdrawer_04',
                ['price'] = 450,
                ['label'] = 'Small Varnished Sidebar',
                ['description'] = 'Norwegian style varnished sidebar',
                ['colorlabel'] = 'Varnished',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_04.png',
                ['object'] = 'hei_heist_str_sideboardl_04',
                ['price'] = 550,
                ['label'] = 'Sideboard Blue',
                ['description'] = 'Classic movie blue sidebar',
                ['colorlabel'] = 'Blue',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_02.png',
                ['object'] = 'hei_heist_str_sideboardl_02',
                ['price'] = 250,
                ['label'] = 'Sideboard Beige',
                ['description'] = 'Beige sidebar with beautiful details and high legs',
                ['colorlabel'] = 'Beige',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/p_v_43_safe_s.png',
                ['object'] = 'p_v_43_safe_s',
                ['price'] = 750,
                ['label'] = 'Safe',
                ['description'] = 'Super secure safe, where did Pablo Escobar hide his money?',
                ['colorlabel'] = 'Green',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_05.png',
                ['object'] = 'hei_heist_str_sideboardl_05',
                ['price'] = 650,
                ['label'] = 'Sideboard Retail ',
                ['description'] = 'Sideboard for retail people, with white and blue details, very good by the way',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/hei_heist_str_sideboardl_03.png',
                ['object'] = 'hei_heist_str_sideboardl_03',
                ['price'] = 550,
                ['label'] = 'Sideboard Wood',
                ['description'] = 'Beautiful solid wooden sideboard, harder than Transformer',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_11.png',
                ['object'] = 'apa_mp_h_str_sideboardl_11',
                ['price'] = 850,
                ['label'] = 'Sideboard Wood Modern',
                ['description'] = 'Beautiful solid wooden sideboard, harder than a turtle sandwich',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/hanging-caninets/apa_mp_h_str_sideboardl_09.png',
                ['object'] = 'apa_mp_h_str_sideboardl_09',
                ['price'] = 550,
                ['label'] = 'Sideboard Simple',
                ['description'] = 'Theres not much to say, its horrible...',
                ['colorlabel'] = 'Simple',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 1000000,
                    slots = 10
                }
            }
        }
    },
    ['carpet'] = {
        label = 'Carpet',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-carpet-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-carpet-blue.svg',
        css = {
            width = 5.5,
            top = 8.8,
            left = 11.3
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwooll_03.png',
                ['object'] = 'apa_mp_h_acc_rugwooll_03',
                ['price'] = 130,
                ['label'] = 'Simple white rug',
                ['description'] = 'A beautiful but simple white rug gets dirty easily.',
                ['colorlabel'] = 'Rought',
                ['colors'] = {
                    {
                        label = 'Smooth',
                        object = 'apa_mp_h_acc_rugwooll_04',
                        price = 130
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwoolm_01.png',
                ['object'] = 'apa_mp_h_acc_rugwoolm_01',
                ['price'] = 160,
                ['label'] = 'Designer rug 01',
                ['description'] = 'A modern design rug',
                ['colorlabel'] = 'White with details',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwoolm_02.png',
                ['object'] = 'apa_mp_h_acc_rugwoolm_02',
                ['price'] = 185,
                ['label'] = 'Designer rug 02',
                ['description'] = 'Black rug with a minimalist and detailed design',
                ['colorlabel'] = 'Black with details',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwoolm_03.png',
                ['object'] = 'apa_mp_h_acc_rugwoolm_03',
                ['price'] = 260,
                ['label'] = 'Designer rug 03',
                ['description'] = 'Beautiful gradient rug, made by Pablo Picasso',
                ['colorlabel'] = 'Gray and white',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwoolm_04.png',
                ['object'] = 'apa_mp_h_acc_rugwoolm_04',
                ['price'] = 115,
                ['label'] = 'Designer rug 03',
                ['description'] = 'A pretty simple and pretty striped rug',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwools_01.png',
                ['object'] = 'apa_mp_h_acc_rugwools_01',
                ['price'] = 190,
                ['label'] = 'Circulated carpet',
                ['description'] = 'A rug with precise circles, hypnotizing, right?',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/apa_mp_h_acc_rugwools_03.png',
                ['object'] = 'apa_mp_h_acc_rugwools_03',
                ['price'] = 290,
                ['label'] = 'Deluxe rug',
                ['description'] = 'Checkered rug in dark colors, perfect for a deluxe home or luxury offices',
                ['colorlabel'] = 'Dark',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/hei_heist_acc_rughidel_01.png',
                ['object'] = 'hei_heist_acc_rughidel_01',
                ['price'] = 350,
                ['label'] = 'Fur rug',
                ['description'] = 'A fur rug, dont ask me what animal it is, you already know that I love animals...',
                ['colorlabel'] = 'Dog',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/carpet/hei_heist_acc_rugwooll_01.png',
                ['object'] = 'hei_heist_acc_rugwooll_01',
                ['price'] = 850,
                ['label'] = 'New Dawn Rug',
                ['description'] = 'An eccentric painting by the majestic painter Quasarovski, a beautiful visual that expresses the new dawn, recommended!',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            }
        }
    },
    ['decals'] = {
        label = 'Decals',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-cosmetics-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-cosmetics-blue.svg',
        css = {
            width = 1.25,
            top = 5.5,
            left = 7.55,
            zIndex = 8
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/vw_prop_vw_colle_pogo.png',
                ['object'] = 'vw_prop_vw_colle_pogo',
                ['price'] = 50,
                ['label'] = 'Collectible Figures',
                ['description'] = 'Incredible collectible dolls!',
                ['colorlabel'] = 'Space Monkey',
                ['colors'] = {
                    {
                        label = 'Alien',
                        object = 'vw_prop_vw_colle_alien',
                        price = 50
                    },
                    {
                        label = 'Impotent Rage',
                        object = 'vw_prop_vw_colle_imporage',
                        price = 50
                    },
                    {
                        label = 'Princess Bubblegum',
                        object = 'vw_prop_vw_colle_prbubble',
                        price = 50
                    },
                    {
                        label = 'Space Ranger Commander',
                        object = 'vw_prop_vw_colle_rsrcomm',
                        price = 50
                    },
                    {
                        label = 'Space Ranger',
                        object = 'vw_prop_vw_colle_rsrgeneric',
                        price = 50
                    },
                    {
                        label = 'Beast',
                        object = 'vw_prop_vw_colle_beast',
                        price = 50
                    },
                    {
                        label = 'Sasquatch',
                        object = 'vw_prop_vw_colle_sasquatch',
                        price = 50
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/v_res_tissues.png',
                ['object'] = 'v_res_tissues',
                ['price'] = 25,
                ['label'] = 'Tissues',
                ['description'] = 'Disposable cotton handkerchiefs',
                ['colorlabel'] = 'Tissues',
                ['colors'] = {
                    {
                        label = 'Tissues TT',
                        object = 'v_res_tt_tissues',
                        price = 25
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_cs_stock_book.png',
                ['object'] = 'prop_cs_stock_book',
                ['price'] = 25,
                ['label'] = 'Book',
                ['description'] = 'Collection of super interesting books, of all genres',
                ['colorlabel'] = 'Classic Book',
                ['colors'] = {
                    {
                        label = 'Book 01a',
                        object = 'vw_prop_book_stack_01a',
                        price = 25
                    },
                    {
                        label = 'Book 01b',
                        object = 'vw_prop_book_stack_01b',
                        price = 25
                    },
                    {
                        label = 'Book 01c',
                        object = 'vw_prop_book_stack_01c',
                        price = 25
                    },
                    {
                        label = 'Book 02a',
                        object = 'vw_prop_book_stack_02a',
                        price = 25
                    },
                    {
                        label = 'Book 02b',
                        object = 'vw_prop_book_stack_02b',
                        price = 25
                    },
                    {
                        label = 'Book 02c',
                        object = 'vw_prop_book_stack_02c',
                        price = 25
                    },
                    {
                        label = 'Book 03a',
                        object = 'vw_prop_book_stack_03a',
                        price = 25
                    },
                    {
                        label = 'Book 03b',
                        object = 'vw_prop_book_stack_03b',
                        price = 25
                    },
                    {
                        label = 'Book 03c',
                        object = 'vw_prop_book_stack_03c',
                        price = 25
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_acc_guitar_01.png',
                ['object'] = 'prop_acc_guitar_01',
                ['price'] = 150,
                ['label'] = 'Guitar',
                ['description'] = 'Guitars of all types, look more here!',
                ['colorlabel'] = 'Guitar ACC 01',
                ['colors'] = {
                    {
                        label = 'Guitar EL 01',
                        object = 'prop_el_guitar_01',
                        price = 150
                    },
                    {
                        label = 'Guitar EL 02',
                        object = 'prop_el_guitar_02',
                        price = 250
                    },
                    {
                        label = 'Guitar EL 03',
                        object = 'prop_el_guitar_03',
                        price = 250
                    },
                    {
                        label = 'Guitar Art',
                        object = 'vw_prop_casino_art_guitar_01a',
                        price = 350
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/v_res_fa_candle02.png',
                ['object'] = 'v_res_fa_candle02',
                ['price'] = 15,
                ['label'] = 'Candle',
                ['description'] = 'All kinds of candelabras and candles, aromatic and smelling like ass too, if you want haha',
                ['colorlabel'] = 'Candle FA',
                ['colors'] = {
                    {
                        label = 'Candle FA 03',
                        object = 'v_res_fa_candle03',
                        price = 15
                    },
                    {
                        label = 'Candle FA 04',
                        object = 'v_res_fa_candle04',
                        price = 15
                    },
                    {
                        label = 'Candle Float',
                        object = 'v_prop_floatcandle',
                        price = 15
                    },
                    {
                        label = 'Candle ACC 01',
                        object = 'apa_mp_h_acc_candles_01',
                        price = 15
                    },
                    {
                        label = 'Candle ACC 02',
                        object = 'apa_mp_h_acc_candles_02',
                        price = 15
                    },
                    {
                        label = 'Candle ACC 04',
                        object = 'apa_mp_h_acc_candles_04',
                        price = 15
                    },
                    {
                        label = 'Candle ACC 05',
                        object = 'apa_mp_h_acc_candles_05',
                        price = 15
                    },
                    {
                        label = 'Candle ACC 06',
                        object = 'apa_mp_h_acc_candles_06',
                        price = 15
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/v_ret_ml_chips1.png',
                ['object'] = 'v_ret_ml_chips1',
                ['price'] = 10,
                ['label'] = 'Chips',
                ['description'] = 'French fries from the best brand in Los Santos, choose your flavor!',
                ['colorlabel'] = 'Simple',
                ['colors'] = {
                    {
                        label = 'Chips 1',
                        object = 'v_ret_ml_chips2',
                        price = 10
                    },
                    {
                        label = 'Chips 2',
                        object = 'v_ret_ml_chips3',
                        price = 10
                    },
                    {
                        label = 'Chips 3',
                        object = 'v_ret_ml_chips4',
                        price = 10
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/v_res_tt_cigs01.png',
                ['object'] = 'v_res_tt_cigs01',
                ['price'] = 20,
                ['label'] = 'Smoke',
                ['description'] = 'Tobacco brands, the best, flavors, without flavors, cigars, etc.',
                ['colorlabel'] = 'Cigs',
                ['colors'] = {
                    {
                        label = 'Lighter CS',
                        object = 'p_cs_lighter_01',
                        price = 20
                    },
                    {
                        label = 'Lighter TT',
                        object = 'v_res_tt_lighter',
                        price = 20
                    },
                    {
                        label = 'Lighter 01',
                        object = 'ex_prop_exec_lighter_01',
                        price = 20
                    },
                    {
                        label = 'Lighter Lux',
                        object = 'lux_prop_lighter_luxe',
                        price = 20
                    },
                    {
                        label = 'Ashtray 1',
                        object = 'v_res_mp_ashtraya',
                        price = 20
                    },
                    {
                        label = 'Ashtray 2',
                        object = 'v_res_mp_ashtrayb',
                        price = 20
                    },
                    {
                        label = 'Ashtray 3',
                        object = 'v_ret_fh_ashtray',
                        price = 20
                    },
                    {
                        label = 'Ashtray 4',
                        object = 'prop_fib_ashtray_01',
                        price = 20
                    },
                    {
                        label = 'Ashtray 5',
                        object = 'ex_prop_exec_ashtray_01',
                        price = 20
                    },
                    {
                        label = 'Cigs 1',
                        object = 'v_ret_ml_cigs',
                        price = 20
                    },
                    {
                        label = 'Cigs 2',
                        object = 'v_ret_ml_cigs2',
                        price = 20
                    },
                    {
                        label = 'Cigs 3',
                        object = 'v_ret_ml_cigs3',
                        price = 20
                    },
                    {
                        label = 'Cigs 4',
                        object = 'v_ret_ml_cigs4',
                        price = 20
                    },
                    {
                        label = 'Cigs 5',
                        object = 'v_ret_ml_cigs5',
                        price = 20
                    },
                    {
                        label = 'Cigs 6',
                        object = 'v_ret_ml_cigs6',
                        price = 20
                    },
                    {
                        label = 'Bong 1',
                        object = 'prop_bong_01',
                        price = 20
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_anim_cash_note.png',
                ['object'] = 'prop_anim_cash_note',
                ['price'] = 10,
                ['label'] = 'Cash',
                ['description'] = 'All kinds of fake money, dont use it to scam anyone...',
                ['colorlabel'] = 'Cash Note',
                ['colors'] = {
                    {
                        label = 'Cash Pile 01',
                        object = 'prop_anim_cash_pile_01',
                        price = 10
                    },
                    {
                        label = 'Cash Pile 02',
                        object = 'prop_anim_cash_pile_02',
                        price = 10
                    },
                    {
                        label = 'Cash Case 01',
                        object = 'prop_cash_case_01',
                        price = 10
                    },
                    {
                        label = 'Cash Case 02',
                        object = 'prop_cash_case_02',
                        price = 10
                    },
                    {
                        label = 'Cash Roll 01',
                        object = 'bkr_prop_bkr_cash_roll_01',
                        price = 10
                    },
                    {
                        label = 'Cash Scatter 01',
                        object = 'bkr_prop_bkr_cash_scatter_01',
                        price = 10
                    },
                    {
                        label = 'Cash Scatter 03',
                        object = 'bkr_prop_bkr_cash_scatter_03',
                        price = 10
                    },
                    {
                        label = 'Cash BKR Pile 01',
                        object = 'bkr_prop_bkr_cashpile_01',
                        price = 10
                    },
                    {
                        label = 'Cash BKR Pile 02',
                        object = 'bkr_prop_bkr_cashpile_02',
                        price = 10
                    },
                    {
                        label = 'Cash BKR Pile 03',
                        object = 'bkr_prop_bkr_cashpile_03',
                        price = 10
                    },
                    {
                        label = 'Cash BKR Pile 05',
                        object = 'bkr_prop_bkr_cashpile_05',
                        price = 10
                    },
                    {
                        label = 'Cash BKR Pile 06',
                        object = 'bkr_prop_bkr_cashpile_06',
                        price = 10
                    },
                    {
                        label = 'Cash Pile',
                        object = 'ex_prop_exec_cashpile',
                        price = 10
                    },
                    {
                        label = 'Cash Crate Half Full',
                        object = 'hei_prop_cash_crate_half_full',
                        price = 10
                    },
                    {
                        label = 'Cash Trolley 01a',
                        object = 'ch_prop_ch_cashtrolley_01a',
                        price = 10
                    },
                    {
                        label = 'Cash Bag 01a',
                        object = 'h4_prop_h4_cash_bag_01a',
                        price = 10
                    },
                    {
                        label = 'Cash Stach 01a',
                        object = 'h4_prop_h4_cash_stack_01a',
                        price = 10
                    },
                    {
                        label = 'Cash Stack 02a',
                        object = 'h4_prop_h4_cash_stack_02a',
                        price = 10
                    },
                    {
                        label = 'Cash Pokerbucket',
                        object = 'bkr_prop_money_pokerbucket',
                        price = 10
                    },
                    {
                        label = 'Cash Pack 01a',
                        object = 'bkr_prop_moneypack_01a',
                        price = 10
                    },
                    {
                        label = 'Cash 02a',
                        object = 'bkr_prop_moneypack_02a',
                        price = 10
                    },
                    {
                        label = 'Cash 03a',
                        object = 'bkr_prop_moneypack_03a',
                        price = 10
                    },
                    {
                        label = 'Cash BC',
                        object = 'ex_prop_crate_money_bc',
                        price = 10
                    },
                    {
                        label = 'Cash SC',
                        object = 'ex_prop_crate_money_sc',
                        price = 10
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_weed_01.png',
                ['object'] = 'prop_weed_01',
                ['price'] = 50,
                ['label'] = 'Weed',
                ['description'] = 'All kinds of toy marijuana plants, they are not real...',
                ['colorlabel'] = 'Weed 01',
                ['colors'] = {
                    {
                        label = 'Weed 02',
                        object = 'prop_weed_02',
                        price = 50
                    },
                    {
                        label = 'Weed Block 01',
                        object = 'prop_weed_block_01',
                        price = 50
                    },
                    {
                        label = 'Weed Bottle',
                        object = 'prop_weed_bottle',
                        price = 50
                    },
                    {
                        label = 'Weed Pallet',
                        object = 'prop_weed_pallet',
                        price = 50
                    },
                    {
                        label = 'Weed Stack 01a',
                        object = 'h4_prop_h4_weed_stack_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Table 01a',
                        object = 'bkr_prop_weed_table_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Spray 01a',
                        object = 'bkr_prop_weed_spray_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Scales 01b',
                        object = 'bkr_prop_weed_scales_01b',
                        price = 50
                    },
                    {
                        label = 'Weed Scales 01a',
                        object = 'bkr_prop_weed_scales_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Pot Stack 01c',
                        object = 'bkr_prop_weed_plantpot_stack_01c',
                        price = 50
                    },
                    {
                        label = 'Weed Pot Stack 01b',
                        object = 'bkr_prop_weed_plantpot_stack_01b',
                        price = 50
                    },
                    {
                        label = 'Weed Pot Stack 01a',
                        object = 'bkr_prop_weed_plantpot_stack_01a',
                        price = 50
                    },
                    {
                        label = 'Weed MED 01b',
                        object = 'bkr_prop_weed_med_01b',
                        price = 50
                    },
                    {
                        label = 'Weed MED 01a',
                        object = 'bkr_prop_weed_med_01a',
                        price = 50
                    },
                    {
                        label = 'Weed LRG 01b',
                        object = 'bkr_prop_weed_lrg_01b',
                        price = 50
                    },
                    {
                        label = 'Weed LRG 01a',
                        object = 'bkr_prop_weed_lrg_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Floor Fan 01a',
                        object = 'bkr_prop_weed_fan_floor_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Ceiling Fan 01a',
                        object = 'bkr_prop_weed_fan_ceiling_01a',
                        price = 50
                    },
                    {
                        label = 'Weed 02a',
                        object = 'bkr_prop_weed_drying_02a',
                        price = 50
                    },
                    {
                        label = 'Weed 01a',
                        object = 'bkr_prop_weed_drying_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Dry 02b',
                        object = 'bkr_prop_weed_dry_02b',
                        price = 50
                    },
                    {
                        label = 'Weed Dry 02a',
                        object = 'bkr_prop_weed_dry_02a',
                        price = 50
                    },
                    {
                        label = 'Weed Dry 01a',
                        object = 'bkr_prop_weed_dry_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Bud 01a',
                        object = 'bkr_prop_weed_bud_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Bud 01b',
                        object = 'bkr_prop_weed_bud_01b',
                        price = 50
                    },
                    {
                        label = 'Weed Bud 02a',
                        object = 'bkr_prop_weed_bud_02a',
                        price = 50
                    },
                    {
                        label = 'Weed Bud 02b',
                        object = 'bkr_prop_weed_bud_02b',
                        price = 50
                    },
                    {
                        label = 'Weed Bucket Open 01a',
                        object = 'bkr_prop_weed_bucket_open_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Bigbag Open 01a',
                        object = 'bkr_prop_weed_bigbag_open_01a',
                        price = 50
                    },
                    {
                        label = 'Weed BigBag 03a',
                        object = 'bkr_prop_weed_bigbag_03a',
                        price = 50
                    },
                    {
                        label = 'Weed BigBag 02a',
                        object = 'bkr_prop_weed_bigbag_02a',
                        price = 50
                    },
                    {
                        label = 'Weed BigBag 01a',
                        object = 'bkr_prop_weed_bigbag_01a',
                        price = 50
                    },
                    {
                        label = 'Weed Small 01c',
                        object = 'bkr_prop_weed_01_small_01c',
                        price = 50
                    },
                    {
                        label = 'Weed Small 01b',
                        object = 'bkr_prop_weed_01_small_01b',
                        price = 50
                    },
                    {
                        label = 'Weed Small 01a',
                        object = 'bkr_prop_weed_01_small_01a',
                        price = 50
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/bkr_prop_meth_acetone.png',
                ['object'] = 'bkr_prop_meth_acetone',
                ['price'] = 50,
                ['label'] = 'Meth',
                ['description'] = 'Acetone and other general chemicals, warning bro!',
                ['colorlabel'] = 'Meth Acetone',
                ['colors'] = {
                    {
                        label = 'Meth Ammonia',
                        object = 'bkr_prop_meth_ammonia',
                        price = 50
                    },
                    {
                        label = 'Meth Hcacid',
                        object = 'bkr_prop_meth_hcacid',
                        price = 50
                    },
                    {
                        label = 'Meth Lithium',
                        object = 'bkr_prop_meth_lithium',
                        price = 50
                    },
                    {
                        label = 'Meth OpenBag',
                        object = 'bkr_prop_meth_openbag_01a',
                        price = 50
                    },
                    {
                        label = 'Meth Phosphorus',
                        object = 'bkr_prop_meth_phosphorus',
                        price = 50
                    },
                    {
                        label = 'Meth Sacid',
                        object = 'bkr_prop_meth_sacid',
                        price = 50
                    },
                    {
                        label = 'Meth Scoop 01a',
                        object = 'bkr_prop_meth_scoop_01a',
                        price = 50
                    },
                    {
                        label = 'Meth Smallbag 01a',
                        object = 'bkr_prop_meth_smallbag_01a',
                        price = 50
                    },
                    {
                        label = 'Meth Smashed Tray 01a',
                        object = 'bkr_prop_meth_smashedtray_01',
                        price = 50
                    },
                    {
                        label = 'Meth Smashed Tray 01 Frag',
                        object = 'bkr_prop_meth_smashedtray_01_frag_',
                        price = 50
                    },
                    {
                        label = 'Meth Smashed Tray 02',
                        object = 'bkr_prop_meth_smashedtray_02',
                        price = 50
                    },
                    {
                        label = 'Meth Sodium',
                        object = 'bkr_prop_meth_sodium',
                        price = 50
                    },
                    {
                        label = 'Meth Table 01a',
                        object = 'bkr_prop_meth_table01a',
                        price = 50
                    },
                    {
                        label = 'Meth Toulene',
                        object = 'bkr_prop_meth_toulene',
                        price = 50
                    },
                    {
                        label = 'Meth Tray 01a',
                        object = 'bkr_prop_meth_tray_01a',
                        price = 50
                    },
                    {
                        label = 'Meth Tray 01b',
                        object = 'bkr_prop_meth_tray_01b',
                        price = 50
                    },
                    {
                        label = 'Meth Tray 02a',
                        object = 'bkr_prop_meth_tray_02a',
                        price = 50
                    }
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/decals/prop_coke_block_half_a.png',
                ['object'] = 'prop_coke_block_half_a',
                ['price'] = 0,
                ['label'] = 'Coke',
                ['description'] = 'Fake cocaine, I swear I dont sell drugs!',
                ['colorlabel'] = 'Coke Block 01',
                ['colors'] = {
                    {
                        label = 'Coke Block Half B',
                        object = 'prop_coke_block_half_b',
                        price = 50
                    },
                    {
                        label = 'Coke Block 01a',
                        object = 'ba_prop_battle_coke_block_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Bakingsoda',
                        object = 'bkr_prop_coke_bakingsoda',
                        price = 50
                    },
                    {
                        label = 'Coke Bottle 01a',
                        object = 'bkr_prop_coke_bakingsoda_o',
                        price = 50
                    },
                    {
                        label = 'Coke Box 01a',
                        object = 'bkr_prop_coke_box_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Cracktry 01',
                        object = 'bkr_prop_coke_cracktray_01',
                        price = 50
                    },
                    {
                        label = 'Coke Cut 01',
                        object = 'bkr_prop_coke_cut_01',
                        price = 50
                    },
                    {
                        label = 'Coke Cut 02',
                        object = 'bkr_prop_coke_cut_02',
                        price = 50
                    },
                    {
                        label = 'Coke Cutblock 01',
                        object = 'bkr_prop_coke_cutblock_01',
                        price = 50
                    },
                    {
                        label = 'Coke Degydrator 01',
                        object = 'bkr_prop_coke_dehydrator_01',
                        price = 50
                    },
                    {
                        label = 'Coke Fullmetalbowl 02',
                        object = 'bkr_prop_coke_fullmetalbowl_02',
                        price = 50
                    },
                    {
                        label = 'Coke Fullscoop 01a',
                        object = 'bkr_prop_coke_fullscoop_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Fullsieve 01a',
                        object = 'bkr_prop_coke_fullsieve_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Metalbowl 01',
                        object = 'bkr_prop_coke_metalbowl_01',
                        price = 50
                    },
                    {
                        label = 'Coke Metalbowl 02',
                        object = 'bkr_prop_coke_metalbowl_02',
                        price = 50
                    },
                    {
                        label = 'Coke Metalbowl 03',
                        object = 'bkr_prop_coke_metalbowl_03',
                        price = 50
                    },
                    {
                        label = 'Coke Mixer 01',
                        object = 'bkr_prop_coke_mixer_01',
                        price = 50
                    },
                    {
                        label = 'Coke Mold 01a',
                        object = 'bkr_prop_coke_mold_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Mold 02a',
                        object = 'bkr_prop_coke_mold_02a',
                        price = 50
                    },
                    {
                        label = 'Coke Mortalpestle',
                        object = 'bkr_prop_coke_mortalpestle',
                        price = 50
                    },
                    {
                        label = 'Coke Painkiller 01a',
                        object = 'bkr_prop_coke_painkiller_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Plastic Bowl 01',
                        object = 'bkr_prop_coke_plasticbowl_01',
                        price = 50
                    },
                    {
                        label = 'Coke Powder 01',
                        object = 'bkr_prop_coke_powder_01',
                        price = 50
                    },
                    {
                        label = 'Coke Powdered Bottle 01',
                        object = 'bkr_prop_coke_powderbottle_01',
                        price = 50
                    },
                    {
                        label = 'Coke Powdered Bottle 02',
                        object = 'bkr_prop_coke_powderbottle_02',
                        price = 50
                    },
                    {
                        label = 'Coke Powdered Milk',
                        object = 'bkr_prop_coke_powderedmilk',
                        price = 50
                    },
                    {
                        label = 'Coke Powdered Milk Open',
                        object = 'bkr_prop_coke_powderedmilk_o',
                        price = 50
                    },
                    {
                        label = 'Coke Press 01aa',
                        object = 'bkr_prop_coke_press_01aa',
                        price = 50
                    },
                    {
                        label = 'Coke Press 01b',
                        object = 'bkr_prop_coke_press_01b',
                        price = 50
                    },
                    {
                        label = 'Coke Scale 01',
                        object = 'bkr_prop_coke_scale_01',
                        price = 50
                    },
                    {
                        label = 'Coke Scale 02',
                        object = 'bkr_prop_coke_scale_02',
                        price = 50
                    },
                    {
                        label = 'Coke Scale 03',
                        object = 'bkr_prop_coke_scale_03',
                        price = 50
                    },
                    {
                        label = 'Coke Spatula 04',
                        object = 'bkr_prop_coke_spatula_04',
                        price = 50
                    },
                    {
                        label = 'Coke Spoon 01',
                        object = 'bkr_prop_coke_spoon_01',
                        price = 50
                    },
                    {
                        label = 'Coke Test Tubes',
                        object = 'bkr_prop_coke_testtubes',
                        price = 50
                    },
                    {
                        label = 'Coke Tin 01',
                        object = 'bkr_prop_coke_tin_01',
                        price = 50
                    },
                    {
                        label = 'Coke Tub 01a',
                        object = 'bkr_prop_coke_tub_01a',
                        price = 50
                    },
                    {
                        label = 'Coke Tube 01',
                        object = 'bkr_prop_coke_tube_01',
                        price = 50
                    },
                    {
                        label = 'Coke Tube 02',
                        object = 'bkr_prop_coke_tube_02',
                        price = 50
                    },
                    {
                        label = 'bkr_prop_coke_tube_03',
                        object = 'Coke Tube 03',
                        price = 50
                    }
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/decals/vw_prop_casino_art_bird_01a.png',
                ['object'] = 'vw_prop_casino_art_bird_01a',
                ['price'] = 240,
                ['label'] = 'Casino Art',
                ['description'] = 'Beautiful decorative for your home, all kinds of details and colors',
                ['colorlabel'] = 'Casino Art Bird 01a',
                ['colors'] = {
                    {
                        label = 'Casino Art Car 01a',
                        object = 'vw_prop_casino_art_car_01a',
                        price = 240
                    },
                    {
                        label = 'Casino Art Car 02a',
                        object = 'vw_prop_casino_art_car_02a',
                        price = 240
                    },
                    {
                        label = 'Casino Art Car 03a',
                        object = 'vw_prop_casino_art_car_03a',
                        price = 240
                    },
                    {
                        label = 'Casino Art Car 04a',
                        object = 'vw_prop_casino_art_car_04a',
                        price = 240
                    },
                    {
                        label = 'Casino Art Car 05a',
                        object = 'vw_prop_casino_art_car_05a',
                        price = 240
                    },
                    {
                        label = 'Casino Art Car 06a',
                        object = 'vw_prop_casino_art_car_06a',
                        price = 240
                    }
                }
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/decals/prop_defilied_ragdoll_01.png',
                ['object'] = 'prop_defilied_ragdoll_01',
                ['price'] = 5,
                ['label'] = 'Defilied Ragdoll',
                ['description'] = 'Rag doll, does not bring internal demons, warning...',
                ['colorlabel'] = 'Classic',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_beware_dog_sign.png',
                ['object'] = 'prop_beware_dog_sign',
                ['price'] = 35,
                ['label'] = 'Dog Sign',
                ['description'] = 'Beware of the dog, an important alert for the outside of your house if you have strange pets...',
                ['colorlabel'] = 'Classic',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/decals/prop_t_telescope_01b.png',
                ['object'] = 'prop_t_telescope_01b',
                ['price'] = 475,
                ['label'] = 'Telescope',
                ['description'] = 'Tactical telescope, with this you can see the stars and even Saturn',
                ['colorlabel'] = 'Classic',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/decals/vw_prop_vw_key_cabinet_01a.png',
                ['object'] = 'vw_prop_vw_key_cabinet_01a',
                ['price'] = 150,
                ['label'] = 'Key Cabinet',
                ['description'] = 'Store your keys here, you know, it has room for your house keys, work keys, car keys, etc...',
                ['colorlabel'] = 'Classic',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/decals/ex_office_citymodel_01.png',
                ['object'] = 'ex_office_citymodel_01',
                ['price'] = 150,
                ['label'] = 'City model 01',
                ['description'] = 'Map of the Saints, tactical and ingenious, a beautiful and huge map!',
                ['colorlabel'] = 'Classic',
                ['colors'] = {}
            }
        }
    },
    ['laptop'] = {
        label = 'Laptop',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-laptop-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-laptop-blue.svg',
        css = {
            width = 2.5,
            top = 5.7,
            left = 17.5,
            zIndex = 11
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/xm_prop_x17_computer_01.png',
                ['object'] = 'xm_prop_x17_computer_01',
                ['price'] = 1200,
                ['label'] = 'Apple computer',
                ['description'] = 'An exceptional brand computer, the best on the market',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/xm_prop_x17_computer_02.png',
                ['object'] = 'xm_prop_x17_computer_02',
                ['price'] = 900,
                ['label'] = 'All in one computer',
                ['description'] = 'An all in one computer, unknown brand...',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/bkr_prop_clubhouse_laptop_01a.png',
                ['object'] = 'bkr_prop_clubhouse_laptop_01a',
                ['price'] = 350,
                ['label'] = 'Single laptop',
                ['description'] = 'An old but very functional laptop',
                ['colorlabel'] = 'Amoled screen',
                ['colors'] = {
                    {
                        label = 'LCD screen',
                        object = 'ex_prop_ex_laptop_01a',
                        price = 250
                    },
                    {
                        label = 'Broken scren',
                        object = 'bkr_prop_clubhouse_laptop_01b',
                        price = 90
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/p_cs_laptop_02.png',
                ['object'] = 'p_cs_laptop_02',
                ['price'] = 460,
                ['label'] = 'Laptop Pavillon',
                ['description'] = 'A half-baked gaming laptop is not the best, but you know, Pavillon is good for everything!',
                ['colorlabel'] = 'Semi-gaming',
                ['colors'] = {
                    {
                        label = 'Closed',
                        object = 'p_cs_laptop_02_w',
                        price = 460
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_laptop_01a.png',
                ['object'] = 'prop_laptop_01a',
                ['price'] = 250,
                ['label'] = 'Laptop Windows Vista',
                ['description'] = 'An old laptop but its like new!',
                ['colorlabel'] = 'Gray',
                ['colors'] = {
                    {
                        label = 'Closed',
                        object = 'prop_laptop_02_closed',
                        price = 250
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/v_ind_ss_laptop.png',
                ['object'] = 'v_ind_ss_laptop',
                ['price'] = 250,
                ['label'] = 'Laptop Windows XP',
                ['description'] = 'An old laptop but its like new!',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/xm_prop_x17_laptop_agent14_01.png',
                ['object'] = 'xm_prop_x17_laptop_agent14_01',
                ['price'] = 900,
                ['label'] = 'Laptop Gaming Gama',
                ['description'] = 'One of the best laptops you can see on the market',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_cs_mouse_01.png',
                ['object'] = 'prop_cs_mouse_01',
                ['price'] = 40,
                ['label'] = 'Mouse Gaming Razer',
                ['description'] = 'The best mice on the market, the best brand, optical and with pad, visit our store here!',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'White',
                        object = 'prop_mouse_01',
                        price = 40
                    },
                    {
                        label = 'Complete',
                        object = 'v_res_mousemat',
                        price = 60
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/hei_prop_hei_cs_keyboard.png',
                ['object'] = 'hei_prop_hei_cs_keyboard',
                ['price'] = 100,
                ['label'] = 'Keyboard',
                ['description'] = 'High quality keyboards, they are not mechanical',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'White',
                        object = 'prop_keyboard_01a',
                        price = 110
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_white_keyboard.png',
                ['object'] = 'prop_white_keyboard',
                ['price'] = 120,
                ['label'] = 'Yellow Gaming',
                ['description'] = 'Yellow mechanical keyboards, the best on the market, Aorius!',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Fat',
                        object = 'v_ind_cfkeyboard',
                        price = 195
                    }
                }
            },
            [11] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_speaker_01.png',
                ['object'] = 'prop_speaker_01',
                ['price'] = 600,
                ['label'] = 'Big Speaker',
                ['description'] = 'A giant musical speaker, I recommend it for parties...',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_speaker_02.png',
                ['object'] = 'prop_speaker_02',
                ['price'] = 250,
                ['label'] = 'Wood Digital Speaker',
                ['description'] = 'A beautiful wooden musical speaker, the accompanying components are missing (not included)',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_speaker_03.png',
                ['object'] = 'prop_speaker_03',
                ['price'] = 350,
                ['label'] = 'Wood buffle',
                ['description'] = 'A beautiful wooden musical speaker, the accompanying components are missing (not included)',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'prop_speaker_05',
                        price = 250
                    }
                }
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/prop_speaker_07.png',
                ['object'] = 'prop_speaker_07',
                ['price'] = 600,
                ['label'] = 'Digital Gaming Speaker',
                ['description'] = 'A digital music speaker, recommended for bands',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'prop_speaker_06',
                        price = 460
                    }
                }
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/sm_prop_smug_speaker.png',
                ['object'] = 'sm_prop_smug_speaker',
                ['price'] = 150,
                ['label'] = 'Digital Speaker',
                ['description'] = 'Small but powerful, what are you waiting for?',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/stt_prop_speakerstack_01a.png',
                ['object'] = 'stt_prop_speakerstack_01a',
                ['price'] = 1290,
                ['label'] = 'Band Speaker',
                ['description'] = 'Huge speaker for bands, recitals, concerts, exclusive and giant!',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/laptop/v_res_pcspeaker.png',
                ['object'] = 'v_res_pcspeaker',
                ['price'] = 180,
                ['label'] = 'Set Gaming Speaker',
                ['description'] = 'A small gaming computer speaker with 7.1 surround sounds',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/laptop/xm_prop_base_computer_01.png',
                ['object'] = 'xm_prop_base_computer_01',
                ['price'] = 2250,
                ['label'] = 'Mining rig',
                ['description'] = 'Find all our crypto mining sets, huge, medium, small, buy the best rigs on the market here!',
                ['colorlabel'] = 'Medium',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'xm_prop_base_computer_06',
                        price = 1400
                    },
                    {
                        label = 'Medium fat',
                        object = 'xm_prop_base_computer_03',
                        price = 1450
                    },
                    {
                        label = 'Medium large',
                        object = 'xm_prop_base_computer_08',
                        price = 1550
                    },
                    {
                        label = 'Medium Closed',
                        object = 'xm_prop_base_computer_04',
                        price = 1700
                    },
                    {
                        label = 'Big',
                        object = 'xm_prop_base_computer_02',
                        price = 2100
                    }
                }
            }
        }
    },
    ['painting'] = {
        label = 'Painting',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-picture-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-picture-blue.svg',
        css = {
            width = 1.5,
            top = 2.0,
            left = 10
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/ex_office_swag_paintings01.png',
                ['object'] = 'ex_office_swag_paintings01',
                ['price'] = 2500,
                ['label'] = 'Kiwi Paintings',
                ['description'] = 'The best works of art, museum paintings and unique ones!',
                ['colorlabel'] = 'Painting',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/ex_office_swag_paintings02.png',
                ['object'] = 'ex_office_swag_paintings02',
                ['price'] = 1260,
                ['label'] = 'Shakira Paintings',
                ['description'] = 'The best works of art, museum paintings and unique ones!',
                ['colorlabel'] = 'Painting',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/ex_office_swag_paintings03.png',
                ['object'] = 'ex_office_swag_paintings03',
                ['price'] = 2120,
                ['label'] = 'Picasso Paintings',
                ['description'] = 'The best works of art, museum paintings and unique ones!',
                ['colorlabel'] = 'Painting',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/apa_mp_h_acc_artwalll_01.png',
                ['object'] = 'apa_mp_h_acc_artwalll_01',
                ['price'] = 200,
                ['label'] = 'Modern art 01',
                ['description'] = 'Beautiful collection of modern paintings',
                ['colorlabel'] = 'Colored',
                ['colors'] = {
                    {
                        label = 'Modern art 02',
                        object = 'apa_mp_h_acc_artwalll_02',
                        price = 200
                    },
                    {
                        label = 'Modern art 03',
                        object = 'apa_mp_h_acc_artwalll_03',
                        price = 200
                    },
                    {
                        label = 'Modern art 04',
                        object = 'apa_mp_h_acc_artwallm_02',
                        price = 200
                    },
                    {
                        label = 'Modern art 05',
                        object = 'apa_mp_h_acc_artwallm_03',
                        price = 200
                    },
                    {
                        label = 'Modern art 06',
                        object = 'apa_mp_h_acc_artwallm_04',
                        price = 200
                    },
                    {
                        label = 'Modern art 07',
                        object = 'apa_mp_h_acc_artwallm_04',
                        price = 200
                    },
                    {
                        label = 'Modern art 08',
                        object = 'apa_p_h_acc_artwalll_01',
                        price = 200
                    },
                    {
                        label = 'Modern art 09',
                        object = 'apa_p_h_acc_artwalll_02',
                        price = 200
                    },
                    {
                        label = 'Modern art 10',
                        object = 'apa_p_h_acc_artwalll_03',
                        price = 200
                    },
                    {
                        label = 'Modern art 11',
                        object = 'apa_p_h_acc_artwallm_03',
                        price = 200
                    },
                    {
                        label = 'Modern art 12',
                        object = 'apa_p_h_acc_artwallm_04',
                        price = 200
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/apa_p_h_acc_artwallm_01.png',
                ['object'] = 'apa_p_h_acc_artwallm_01',
                ['price'] = 250,
                ['label'] = 'Minimalist grainy painting',
                ['description'] = 'This painting inspires the happiness of a flower in the morning, smelling like cheese fermented with a lot of love',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/apa_p_h_acc_artwalls_03.png',
                ['object'] = 'apa_p_h_acc_artwalls_03',
                ['price'] = 500,
                ['label'] = 'Soccer art',
                ['description'] = 'Paintings signed by famous players',
                ['colorlabel'] = 'Number 6',
                ['colors'] = {
                    {
                        label = 'Number 3',
                        object = 'apa_p_h_acc_artwalls_04',
                        price = 550
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/painting/hei_heist_acc_artgolddisc_01.png',
                ['object'] = 'hei_heist_acc_artgolddisc_01',
                ['price'] = 60,
                ['label'] = 'Vinyl records',
                ['description'] = 'Collectible records of commemorative bands, some are exclusive',
                ['colorlabel'] = 'Queen',
                ['colors'] = {
                    {
                        label = 'The Doors',
                        object = 'hei_heist_acc_artgolddisc_02',
                        price = 60
                    },
                    {
                        label = 'Toto',
                        object = 'hei_heist_acc_artgolddisc_03',
                        price = 60
                    },
                    {
                        label = 'Bring me the horizon',
                        object = 'hei_heist_acc_artgolddisc_04',
                        price = 60
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/painting/ng_proc_paintcan01a.png',
                ['object'] = 'ng_proc_paintcan01a',
                ['price'] = 55,
                ['label'] = 'Huge paint pot',
                ['description'] = 'Multiple paints to paint pictures',
                ['colorlabel'] = 'Red',
                ['colors'] = {
                    {
                        label = 'Big blue',
                        object = 'prop_paints_can03',
                        price = 100
                    },
                    {
                        label = 'Small blue',
                        object = 'prop_paints_can04',
                        price = 25
                    },
                    {
                        label = 'Big Green',
                        object = 'prop_paints_can06',
                        price = 80
                    },
                    {
                        label = 'Paleta completa',
                        object = 'prop_paints_pallete01',
                        price = 290
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/painting/prop_paint_roller.png',
                ['object'] = 'prop_paint_roller',
                ['price'] = 15,
                ['label'] = 'Paint roller',
                ['description'] = 'You cant paint your house without a roller, right?',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Ink holder',
                        object = 'prop_paint_tray',
                        price = 9
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/painting/prop_paint_spray01b.png',
                ['object'] = 'prop_paint_spray01b',
                ['price'] = 20,
                ['label'] = 'Color Spray',
                ['description'] = 'Color spray, choose your model here!',
                ['colorlabel'] = 'Open',
                ['colors'] = {
                    {
                        label = 'Closed',
                        object = 'prop_paint_spray01a',
                        price = 25
                    }
                }
            },
            [11] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/painting/prop_paint_wpaper01.png',
                ['object'] = 'prop_paint_wpaper01',
                ['price'] = 155,
                ['label'] = 'Canvas Pack',
                ['description'] = 'Blank canvases for you to start expressing your art!',
                ['colorlabel'] = 'Pack',
                ['colors'] = {}
            }
        }
    },
    ['wardrobe'] = {
        label = 'Wardrobe',
        img = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-wardrobe-blue.svg',
        navigation = 3,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/bedroom/bedroom-wardrobe-blue.svg',
        css = {
            width = 4.25,
            top = 1.0,
            left = 3.0,
            zIndex = 6
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/wardrobe/ch_prop_ch_service_locker_01a.png',
                ['object'] = 'ch_prop_ch_service_locker_01a',
                ['price'] = 290,
                ['label'] = 'Big locker',
                ['description'] = 'A metal locker with keys, very good for schools or institutes!',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Medium',
                        object = 'ch_prop_ch_service_locker_02a',
                        price = 190,
                        type = 'gardrobe',
                        offset = {
                            x = 0.0,
                            y = 0.0,
                            z = 0.0
                        }
                    }
                },
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/wardrobe/apa_mp_h_str_shelffloorm_02.png',
                ['object'] = 'apa_mp_h_str_shelffloorm_02',
                ['price'] = 450,
                ['label'] = 'Luxurious wooden wardrobe',
                ['description'] = 'A huge and beautiful wardrobe, very luxurious and used in luxury homes',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/wardrobe/bkr_prop_gunlocker_01a.png',
                ['object'] = 'bkr_prop_gunlocker_01a',
                ['price'] = 150,
                ['label'] = 'Open box office',
                ['description'] = 'An open locker that could be used as a closet or to store some miscellaneous things',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/wardrobe/apa_mp_h_str_shelfwallm_01.png',
                ['object'] = 'apa_mp_h_str_shelfwallm_01',
                ['price'] = 255,
                ['label'] = 'Shelf style cabinet',
                ['description'] = 'A shelf but can be used as a wardrobe, here you can put your stacked clothes or sneakers in a modern and beautiful way!',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/wardrobe/p_cs_locker_01_s.png',
                ['object'] = 'p_cs_locker_01_s',
                ['price'] = 70,
                ['label'] = 'Simple locker',
                ['description'] = 'A completely simple metal locker, there is nothing more to say honestly...',
                ['colorlabel'] = 'Gray',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/bedroom/items/wardrobe/v_serv_cupboard_01.png',
                ['object'] = 'v_serv_cupboard_01',
                ['price'] = 420,
                ['label'] = 'Large closet',
                ['description'] = 'A large white wardrobe with double doors, perfect for storing winter clothes',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/bedroom/items/wardrobe/apa_mp_h_str_shelffreel_01.png',
                ['object'] = 'apa_mp_h_str_shelffreel_01',
                ['price'] = 590,
                ['label'] = 'Huge luxury closet',
                ['description'] = 'A huge closet-style shelf in minimalist white color, a beautiful piece of furniture for deluxe people',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'gardrobe',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                }
            }
        }
    },
    ['sofa'] = {
        label = 'Sofa',
        img = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-bench-blue.svg',
        navigation = 5,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-bench-blue.svg',
        css = {
            width = 5.0,
            top = 8.2,
            left = 9.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofacorn_01.png',
                ['object'] = 'apa_mp_h_stn_sofacorn_01',
                ['price'] = 1200,
                ['label'] = 'Stylish huge sofa',
                ['description'] = 'Super stylish sofa sets in many colors',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'apa_mp_h_stn_sofacorn_05',
                        price = 1200
                    },
                    {
                        label = 'Green',
                        object = 'apa_mp_h_stn_sofacorn_06',
                        price = 1200
                    },
                    {
                        label = 'Dark blue',
                        object = 'apa_mp_h_stn_sofacorn_07',
                        price = 1200
                    },
                    {
                        label = 'Gray',
                        object = 'apa_mp_h_stn_sofacorn_08',
                        price = 1200
                    },
                    {
                        label = 'Dark gray',
                        object = 'apa_mp_h_stn_sofacorn_09',
                        price = 1200
                    },
                    {
                        label = 'White and red',
                        object = 'apa_mp_h_stn_sofacorn_10',
                        price = 1200
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofa2seat_02.png',
                ['object'] = 'apa_mp_h_stn_sofa2seat_02',
                ['price'] = 350,
                ['label'] = 'Two seater sofas',
                ['description'] = 'Two-seater sofas of various colors and models for sale',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Modern white',
                        object = 'hei_heist_stn_sofa2seat_03',
                        price = 350
                    },
                    {
                        label = 'Brown',
                        object = 'hei_heist_stn_sofa2seat_06',
                        price = 290
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/hei_heist_stn_sofacorn_05.png',
                ['object'] = 'hei_heist_stn_sofacorn_05',
                ['price'] = 1050,
                ['label'] = 'Beautiful huge sofa',
                ['description'] = 'Huge and very pretty sofa, in two varieties of very cheerful colors',
                ['colorlabel'] = 'Blue',
                ['colors'] = {
                    {
                        label = 'Green',
                        object = 'hei_heist_stn_sofacorn_06',
                        price = 1080
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofa_daybed_01.png',
                ['object'] = 'apa_mp_h_stn_sofa_daybed_01',
                ['price'] = 150,
                ['label'] = 'Nap chair',
                ['description'] = 'A beautiful armchair to sleep and rest, simple, also more luxurious in black',
                ['colorlabel'] = 'Brown',
                ['colors'] = {
                    {
                        label = 'Black',
                        object = 'apa_mp_h_stn_sofa_daybed_02',
                        price = 200
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_yacht_sofa_01.png',
                ['object'] = 'apa_mp_h_yacht_sofa_01',
                ['price'] = 800,
                ['label'] = 'Modern long sofa',
                ['description'] = 'Complete and modern sofa, quality price is the best you can find brother',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Brown',
                        object = 'apa_mp_h_yacht_sofa_02',
                        price = 450
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/prop_yaught_sofa_01.png',
                ['object'] = 'prop_yaught_sofa_01',
                ['price'] = 300,
                ['label'] = 'Single double sofa',
                ['description'] = 'A light, simple, two-seater sofa',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {
                    {
                        label = 'Green',
                        object = 'p_yacht_sofa_01_s',
                        price = 300
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/hei_heist_stn_sofa3seat_01.png',
                ['object'] = 'hei_heist_stn_sofa3seat_01',
                ['price'] = 360,
                ['label'] = 'Mattress with pillows',
                ['description'] = 'Mattress style armchair set with pillows, or without pillows, large and small',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Complete',
                        object = 'hei_heist_stn_sofa3seat_02',
                        price = 420
                    },
                    {
                        label = 'Complete large',
                        object = 'hei_heist_stn_sofa3seat_06',
                        price = 475
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/v_tre_sofa_mess_b_s.png',
                ['object'] = 'v_tre_sofa_mess_b_s',
                ['price'] = 400,
                ['label'] = 'Old but nice sofa',
                ['description'] = 'Two-seater sofa with an old but functional aesthetic, not a bad price if you want it...',
                ['colorlabel'] = 'Light blue',
                ['colors'] = {
                    {
                        label = 'Dark blue',
                        object = 'v_tre_sofa_mess_c_s',
                        price = 400
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/xm_lab_sofa_01.png',
                ['object'] = 'xm_lab_sofa_01',
                ['price'] = 550,
                ['label'] = 'Modern white sofa',
                ['description'] = 'Modern and long sofa in various colors, this sofa is low and has multiple pillows divided throughout its interior',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Black',
                        object = 'xm_lab_sofa_02',
                        price = 550
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/prop_bench_01a.png',
                ['object'] = 'prop_bench_01a',
                ['price'] = 150,
                ['label'] = 'Outdoor benches',
                ['description'] = 'Outdoor bench set, multiple types and colors available',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'prop_bench_01b',
                        price = 150
                    },
                    {
                        label = 'Green',
                        object = 'prop_bench_01c',
                        price = 150
                    },
                    {
                        label = 'Big black',
                        object = 'prop_bench_02',
                        price = 170
                    },
                    {
                        label = 'Crome blue',
                        object = 'prop_bench_03',
                        price = 150
                    },
                    {
                        label = 'Wood green',
                        object = 'prop_bench_04',
                        price = 90
                    },
                    {
                        label = 'Street bench',
                        object = 'prop_bench_05',
                        price = 120
                    },
                    {
                        label = 'Old street bench',
                        object = 'prop_bench_08',
                        price = 90
                    },
                    {
                        label = 'Single street bench',
                        object = 'prop_bench_10',
                        price = 70
                    },
                    {
                        label = 'Modern street bench',
                        object = 'prop_bench_11',
                        price = 190
                    }
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/bkr_prop_clubhouse_sofa_01a.png',
                ['object'] = 'bkr_prop_clubhouse_sofa_01a',
                ['price'] = 550,
                ['label'] = 'Intense sofa',
                ['description'] = 'Normal sofa, but very beautiful, as black as darkness',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/imp_prop_impexp_sofabed_01a.png',
                ['object'] = 'imp_prop_impexp_sofabed_01a',
                ['price'] = 450,
                ['label'] = 'Sofa bed',
                ['description'] = 'Normal folding sofa bed',
                ['colorlabel'] = 'Black and white',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/p_res_sofa_l_s.png',
                ['object'] = 'p_res_sofa_l_s',
                ['price'] = 650,
                ['label'] = 'Antique king sofa',
                ['description'] = 'The sofa where kings sit, this reconditioned antique sofa is a luxury',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/p_v_med_p_sofa_s.png',
                ['object'] = 'p_v_med_p_sofa_s',
                ['price'] = 240,
                ['label'] = 'Normal sofa',
                ['description'] = 'A simple leather style sofa, very pretty but nothing that stands out',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/gr_dlc_gr_yacht_props_lounger.png',
                ['object'] = 'gr_dlc_gr_yacht_props_lounger',
                ['price'] = 120,
                ['label'] = 'Sunbathing chair',
                ['description'] = 'Sunbathing chair, if you have needs, its cheap and you can sleep here...',
                ['colorlabel'] = 'Single',
                ['colors'] = {}
            }
        }
    },
    ['camera'] = {
        label = 'Camera',
        img = Config.ImagePath .. 'decorate/categories/rooms/camera/garden-camera-blue.svg',
        navigation = 5,
        dynamic = true,
        css = {
            width = 5.5,
            top = -3.4,
            left = 12.3
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/cam/ch_prop_ch_cctv_cam_01a.png',
                ['object'] = 'ch_prop_ch_cctv_cam_01a',
                ['price'] = 1200,
                ['label'] = 'Security Camera',
                ['description'] = 'Advanced security camera with dynamic synchronized surveillance',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['light'] = {
        label = 'Light',
        img = Config.ImagePath .. 'decorate/categories/rooms/light/garden-lamp-blue.svg',
        navigation = 5,
        dynamic = true,
        css = {
            width = 4.5,
            top = 4.1,
            left = 9.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/light/v_res_mplatesml.png',
                ['object'] = 'v_res_mplatesml',
                ['price'] = 1200,
                ['label'] = 'Spotlight',
                ['description'] = 'An RGB light spot!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['couch'] = {
        label = 'Couch',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-couch-blue.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-couch-blue.svg',
        css = {
            width = 8,
            top = 5.2,
            left = 4.0
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofacorn_01.png',
                ['object'] = 'apa_mp_h_stn_sofacorn_01',
                ['price'] = 1200,
                ['label'] = 'Stylish huge sofa',
                ['description'] = 'Super stylish sofa sets in many colors',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'apa_mp_h_stn_sofacorn_05',
                        price = 1200
                    },
                    {
                        label = 'Green',
                        object = 'apa_mp_h_stn_sofacorn_06',
                        price = 1200
                    },
                    {
                        label = 'Dark blue',
                        object = 'apa_mp_h_stn_sofacorn_07',
                        price = 1200
                    },
                    {
                        label = 'Gray',
                        object = 'apa_mp_h_stn_sofacorn_08',
                        price = 1200
                    },
                    {
                        label = 'Dark gray',
                        object = 'apa_mp_h_stn_sofacorn_09',
                        price = 1200
                    },
                    {
                        label = 'White and red',
                        object = 'apa_mp_h_stn_sofacorn_10',
                        price = 1200
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofa2seat_02.png',
                ['object'] = 'apa_mp_h_stn_sofa2seat_02',
                ['price'] = 350,
                ['label'] = 'Two seater sofas',
                ['description'] = 'Two-seater sofas of various colors and models for sale',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Modern white',
                        object = 'hei_heist_stn_sofa2seat_03',
                        price = 350
                    },
                    {
                        label = 'Brown',
                        object = 'hei_heist_stn_sofa2seat_06',
                        price = 290
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/hei_heist_stn_sofacorn_05.png',
                ['object'] = 'hei_heist_stn_sofacorn_05',
                ['price'] = 1050,
                ['label'] = 'Beautiful huge sofa',
                ['description'] = 'Huge and very pretty sofa, in two varieties of very cheerful colors',
                ['colorlabel'] = 'Blue',
                ['colors'] = {
                    {
                        label = 'Green',
                        object = 'hei_heist_stn_sofacorn_06',
                        price = 1080
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_stn_sofa_daybed_01.png',
                ['object'] = 'apa_mp_h_stn_sofa_daybed_01',
                ['price'] = 150,
                ['label'] = 'Nap chair',
                ['description'] = 'A beautiful armchair to sleep and rest, simple, also more luxurious in black',
                ['colorlabel'] = 'Brown',
                ['colors'] = {
                    {
                        label = 'Black',
                        object = 'apa_mp_h_stn_sofa_daybed_02',
                        price = 200
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/apa_mp_h_yacht_sofa_01.png',
                ['object'] = 'apa_mp_h_yacht_sofa_01',
                ['price'] = 800,
                ['label'] = 'Modern long sofa',
                ['description'] = 'Complete and modern sofa, quality price is the best you can find brother',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Brown',
                        object = 'apa_mp_h_yacht_sofa_02',
                        price = 450
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/prop_yaught_sofa_01.png',
                ['object'] = 'prop_yaught_sofa_01',
                ['price'] = 300,
                ['label'] = 'Single double sofa',
                ['description'] = 'A light, simple, two-seater sofa',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {
                    {
                        label = 'Green',
                        object = 'p_yacht_sofa_01_s',
                        price = 300
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/hei_heist_stn_sofa3seat_01.png',
                ['object'] = 'hei_heist_stn_sofa3seat_01',
                ['price'] = 360,
                ['label'] = 'Mattress with pillows',
                ['description'] = 'Mattress style armchair set with pillows, or without pillows, large and small',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Complete',
                        object = 'hei_heist_stn_sofa3seat_02',
                        price = 420
                    },
                    {
                        label = 'Complete large',
                        object = 'hei_heist_stn_sofa3seat_06',
                        price = 475
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/v_tre_sofa_mess_b_s.png',
                ['object'] = 'v_tre_sofa_mess_b_s',
                ['price'] = 400,
                ['label'] = 'Old but nice sofa',
                ['description'] = 'Two-seater sofa with an old but functional aesthetic, not a bad price if you want it...',
                ['colorlabel'] = 'Light blue',
                ['colors'] = {
                    {
                        label = 'Dark blue',
                        object = 'v_tre_sofa_mess_c_s',
                        price = 400
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/xm_lab_sofa_01.png',
                ['object'] = 'xm_lab_sofa_01',
                ['price'] = 550,
                ['label'] = 'Modern white sofa',
                ['description'] = 'Modern and long sofa in various colors, this sofa is low and has multiple pillows divided throughout its interior',
                ['colorlabel'] = 'White',
                ['colors'] = {
                    {
                        label = 'Black',
                        object = 'xm_lab_sofa_02',
                        price = 550
                    }
                }
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/prop_bench_01a.png',
                ['object'] = 'prop_bench_01a',
                ['price'] = 150,
                ['label'] = 'Outdoor benches',
                ['description'] = 'Outdoor bench set, multiple types and colors available',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'prop_bench_01b',
                        price = 150
                    },
                    {
                        label = 'Green',
                        object = 'prop_bench_01c',
                        price = 150
                    },
                    {
                        label = 'Big black',
                        object = 'prop_bench_02',
                        price = 170
                    },
                    {
                        label = 'Crome blue',
                        object = 'prop_bench_03',
                        price = 150
                    },
                    {
                        label = 'Wood green',
                        object = 'prop_bench_04',
                        price = 90
                    },
                    {
                        label = 'Street bench',
                        object = 'prop_bench_05',
                        price = 120
                    },
                    {
                        label = 'Old street bench',
                        object = 'prop_bench_08',
                        price = 90
                    },
                    {
                        label = 'Single street bench',
                        object = 'prop_bench_10',
                        price = 70
                    },
                    {
                        label = 'Modern street bench',
                        object = 'prop_bench_11',
                        price = 190
                    }
                }
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/bkr_prop_clubhouse_sofa_01a.png',
                ['object'] = 'bkr_prop_clubhouse_sofa_01a',
                ['price'] = 550,
                ['label'] = 'Intense sofa',
                ['description'] = 'Normal sofa, but very beautiful, as black as darkness',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/imp_prop_impexp_sofabed_01a.png',
                ['object'] = 'imp_prop_impexp_sofabed_01a',
                ['price'] = 450,
                ['label'] = 'Sofa bed',
                ['description'] = 'Normal folding sofa bed',
                ['colorlabel'] = 'Black and white',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/p_res_sofa_l_s.png',
                ['object'] = 'p_res_sofa_l_s',
                ['price'] = 650,
                ['label'] = 'Antique king sofa',
                ['description'] = 'The sofa where kings sit, this reconditioned antique sofa is a luxury',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/sofa/p_v_med_p_sofa_s.png',
                ['object'] = 'p_v_med_p_sofa_s',
                ['price'] = 240,
                ['label'] = 'Normal sofa',
                ['description'] = 'A simple leather style sofa, very pretty but nothing that stands out',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/sofa/gr_dlc_gr_yacht_props_lounger.png',
                ['object'] = 'gr_dlc_gr_yacht_props_lounger',
                ['price'] = 120,
                ['label'] = 'Sunbathing chair',
                ['description'] = 'Sunbathing chair, if you have needs, its cheap and you can sleep here...',
                ['colorlabel'] = 'Single',
                ['colors'] = {}
            }
        }
    },
    ['couchtable'] = {
        label = 'Couch Table',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-table-blue.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-table-blue.svg',
        css = {
            zIndex = 2,
            top = 8.0,
            left = 8.0,
            width = 9.0
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_01.png',
                ['object'] = 'apa_mp_h_din_table_01',
                ['price'] = 550,
                ['label'] = 'Modern Glass Table',
                ['description'] = 'A modern and beautiful glass table, a little expensive, but worth it',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_04.png',
                ['object'] = 'apa_mp_h_din_table_04',
                ['price'] = 420,
                ['label'] = 'Single Glass Table',
                ['description'] = 'Beautiful metal and glass table',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_din_table_06.png',
                ['object'] = 'apa_mp_h_din_table_06',
                ['price'] = 210,
                ['label'] = 'Modern Plastic Table',
                ['description'] = 'A beautiful modern plastic and metal table, good price by the way...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_01.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_01',
                ['price'] = 190,
                ['label'] = 'Coffee Table',
                ['description'] = 'This is where Prince Quasar drank his coffee, did you know that? Me neither, but it says so on the label haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_coffee_table_02.png',
                ['object'] = 'apa_mp_h_yacht_coffee_table_02',
                ['price'] = 330,
                ['label'] = 'Yatch Coffee Table',
                ['description'] = 'This coffee table is suitable for yacht trips, the truth is it is very hard and robust, beautiful, right?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_yacht_side_table_01.png',
                ['object'] = 'apa_mp_h_yacht_side_table_01',
                ['price'] = 90,
                ['label'] = 'Mini Coffee Table',
                ['description'] = 'Small coffee table, in a studio apartment it would look perfect, it takes up almost no space',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_ven_market_table1.png',
                ['object'] = 'prop_ven_market_table1',
                ['price'] = 150,
                ['label'] = 'Exterior table',
                ['description'] = 'Simple and beautiful outdoor table',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_yacht_table_03.png',
                ['object'] = 'prop_yacht_table_03',
                ['price'] = 400,
                ['label'] = 'Yatch plastic table',
                ['description'] = 'High density plastic yacht table set',
                ['colorlabel'] = 'Big',
                ['colors'] = {
                    {
                        label = 'Medium',
                        object = 'prop_yacht_table_02',
                        price = 250
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/v_ret_fh_dinetable.png',
                ['object'] = 'v_ret_fh_dinetable',
                ['price'] = 830,
                ['label'] = 'Horror table',
                ['description'] = 'Above this table I think Frankenstain autopsy was done haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_07.png',
                ['object'] = 'hei_heist_din_table_07',
                ['price'] = 1200,
                ['label'] = 'Glass deluxe table',
                ['description'] = 'A beautiful and rounded glass table with a deluxe style and high quality',
                ['colorlabel'] = 'Glass',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_04.png',
                ['object'] = 'hei_heist_din_table_04',
                ['price'] = 500,
                ['label'] = 'Quartz crystal',
                ['description'] = 'Precious quartz crystal table',
                ['colorlabel'] = 'Crystal',
                ['colors'] = {
                    {
                        label = 'Small',
                        object = 'apa_mp_h_str_sideboards_02',
                        price = 300
                    }
                }
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/hei_heist_din_table_06.png',
                ['object'] = 'hei_heist_din_table_06',
                ['price'] = 600,
                ['label'] = 'Familiar table',
                ['description'] = 'A huge table and chairs set for the whole family',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_fbi3_coffee_table.png',
                ['object'] = 'prop_fbi3_coffee_table',
                ['price'] = 300,
                ['label'] = 'Modern coffee table',
                ['description'] = 'Low coffee table, beautiful and delicious, ah no, you cant eat that haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_01.png',
                ['object'] = 'prop_table_01',
                ['price'] = 200,
                ['label'] = 'Pino table 01',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_02.png',
                ['object'] = 'prop_table_02',
                ['price'] = 250,
                ['label'] = 'Pino table 02',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_04.png',
                ['object'] = 'prop_table_04',
                ['price'] = 320,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_05.png',
                ['object'] = 'prop_table_05',
                ['price'] = 360,
                ['label'] = 'Pino table 03',
                ['description'] = 'Simple and detailed wooden table model',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidesml_01.png',
                ['object'] = 'apa_mp_h_tab_sidesml_01',
                ['price'] = 350,
                ['label'] = 'Small kit tables',
                ['description'] = 'An economical kit of tables for your home',
                ['colorlabel'] = 'Kit',
                ['colors'] = {
                    {
                        label = 'Single',
                        object = 'apa_mp_h_tab_sidesml_02',
                        price = 50
                    }
                }
            },
            [19] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_sidelrg_02.png',
                ['object'] = 'apa_mp_h_tab_sidelrg_02',
                ['price'] = 760,
                ['label'] = 'Designer glass table',
                ['description'] = 'A beautiful glass table with a modern, artistic design.',
                ['colorlabel'] = 'Glass',
                ['colors'] = {
                    {
                        label = 'Economic',
                        object = 'apa_mp_h_tab_sidelrg_01',
                        price = 560
                    }
                }
            },
            [20] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/bkr_prop_fakeid_table.png',
                ['object'] = 'bkr_prop_fakeid_table',
                ['price'] = 110,
                ['label'] = 'Small Table',
                ['description'] = 'Small light table that still serves to eat, foldable and takes up almost no space',
                ['colorlabel'] = 'Yellow',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 3
                }
            },
            [21] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_weed_table_01b.png',
                ['object'] = 'bkr_prop_weed_table_01b',
                ['price'] = 150,
                ['label'] = 'Folding table',
                ['description'] = 'A folding table, dont look at the other options, are they somewhat... illegal?',
                ['colorlabel'] = 'Single',
                ['colors'] = {
                    {
                        label = 'Weed',
                        object = 'bkr_prop_weed_table_01a',
                        price = 800
                    },
                    {
                        label = 'Chemicals',
                        object = 'bkr_prop_meth_table01a',
                        price = 1250
                    }
                }
            },
            [22] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_06.png',
                ['object'] = 'prop_table_06',
                ['price'] = 350,
                ['label'] = 'Garden Table',
                ['description'] = 'An ideal outdoor table for your garden!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [23] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_08.png',
                ['object'] = 'prop_table_08',
                ['price'] = 250,
                ['label'] = 'Picnic Table',
                ['description'] = 'Oak table for outdoors or horror houses, you know, boo!',
                ['colorlabel'] = 'Roble',
                ['colors'] = {}
            },
            [24] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_07.png',
                ['object'] = 'prop_table_07',
                ['price'] = 125,
                ['label'] = 'Mini bar table',
                ['description'] = 'Ideal for bars or cafes!',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [25] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_01.png',
                ['object'] = 'prop_table_para_comb_01',
                ['price'] = 600,
                ['label'] = 'Table with pergola',
                ['description'] = 'Collection of tables with pergolas, beautiful!',
                ['colorlabel'] = 'Black',
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'prop_table_para_comb_03',
                        price = 600
                    },
                    {
                        label = 'White',
                        object = 'prop_table_para_comb_04',
                        price = 600
                    }
                }
            },
            [26] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/prop_table_para_comb_02.png',
                ['object'] = 'prop_table_para_comb_02',
                ['price'] = 550,
                ['label'] = 'Single Table whit pergola',
                ['description'] = 'This outdoor pergola table is ideal for simple shops or kiosks',
                ['colorlabel'] = 'Plastic',
                ['colors'] = {
                    {
                        label = 'Roble',
                        object = 'prop_table_para_comb_05',
                        price = 650
                    }
                }
            },
            [27] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tablesmall_01.png',
                ['object'] = 'prop_tablesmall_01',
                ['price'] = 430,
                ['label'] = 'Small tea table',
                ['description'] = 'Low table, living room size to have tea while watching a nice movie on Netflix',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [28] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_table_tennis.png',
                ['object'] = 'prop_table_tennis',
                ['price'] = 1300,
                ['label'] = 'Tenis table',
                ['description'] = 'Beautiful, huge pingpong table but does not include rackets',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Rackets',
                        object = 'prop_table_ten_bat',
                        price = 25
                    }
                }
            },
            [29] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_pooltable_02.png',
                ['object'] = 'prop_pooltable_02',
                ['price'] = 3500,
                ['label'] = 'Pool table',
                ['description'] = 'Huge and expensive pool table, very expensive',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Purple',
                        object = 'prop_pooltable_3b',
                        price = 3700
                    }
                }
            },
            [30] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/prop_tri_table_01.png',
                ['object'] = 'prop_tri_table_01',
                ['price'] = 250,
                ['label'] = 'Voting table',
                ['description'] = 'Presidential voting table, yeah exactly...',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [31] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/kitchen/items/tables/ex_mp_h_din_table_05.png',
                ['object'] = 'ex_mp_h_din_table_05',
                ['price'] = 430,
                ['label'] = 'Normal Table',
                ['description'] = 'A huge but quite simple table, it is widely used in offices',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [32] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/apa_mp_h_tab_coffee_08.png',
                ['object'] = 'apa_mp_h_tab_coffee_08',
                ['price'] = 550,
                ['label'] = 'Modern Coffee Table',
                ['description'] = 'A very modern coffee table!',
                ['colorlabel'] = 'White',
                ['colors'] = {},
                type = 'stash',
                offset = {
                    x = 0.0,
                    y = 0.0,
                    z = 0.0
                },
                stash = {
                    maxweight = 50000,
                    slots = 5
                }
            },
            [33] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/ex_prop_ex_console_table_01.png',
                ['object'] = 'ex_prop_ex_console_table_01',
                ['price'] = 550,
                ['label'] = 'Wifi Table',
                ['description'] = 'A very old coffee table, it looks like grandma',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [34] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/kitchen/items/tables/bkr_prop_coke_pallet_01a.png',
                ['object'] = 'bkr_prop_coke_pallet_01a',
                ['price'] = 20,
                ['label'] = '"Table" for the poor',
                ['description'] = 'If you dont have much money... go ahead buddy haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            }
        }
    },
    ['bush'] = {
        label = 'Bushes',
        img = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-bushes-blue.svg',
        navigation = 5,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-bushes-blue.svg',
        css = {
            width = 3.7,
            top = 7.0,
            left = 6.4
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_med_03.png',
                ['object'] = 'prop_bush_med_03',
                ['price'] = 150,
                ['label'] = 'Green bush',
                ['description'] = 'A medium-sized shrub, beautiful for outdoors',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_med_05.png',
                ['object'] = 'prop_bush_med_05',
                ['price'] = 125,
                ['label'] = 'Dry bush',
                ['description'] = 'A dry shrub that can be planted in deserts or arid areas',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_med_06.png',
                ['object'] = 'prop_bush_med_06',
                ['price'] = 190,
                ['label'] = 'Big dry bush',
                ['description'] = 'A dry shrub that can be planted in deserts or arid areas',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_lrg_01d.png',
                ['object'] = 'prop_bush_lrg_01d',
                ['price'] = 280,
                ['label'] = 'Big green bush',
                ['description'] = 'A big-sized shrub, beautiful for outdoors',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_lrg_03.png',
                ['object'] = 'prop_bush_lrg_03',
                ['price'] = 280,
                ['label'] = 'Little tree with pot',
                ['description'] = 'Small tree with a very green pot',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_lrg_01c.png',
                ['object'] = 'prop_bush_lrg_01c',
                ['price'] = 350,
                ['label'] = 'Big tree with pot',
                ['description'] = 'Big tree with a very green pot',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_lrg_01c_cr.png',
                ['object'] = 'prop_bush_lrg_01c_cr',
                ['price'] = 320,
                ['label'] = 'Flat tree with pot',
                ['description'] = 'Flat tree with a very green pot',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_lrg_01e_cr2.png',
                ['object'] = 'prop_bush_lrg_01e_cr2',
                ['price'] = 310,
                ['label'] = 'Medium large green bush',
                ['description'] = 'A large-sized shrub, beautiful for outdoors',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_07.png',
                ['object'] = 'prop_bush_neat_07',
                ['price'] = 120,
                ['label'] = 'Small tree',
                ['description'] = 'Small outdoor tree, it doesnt grow much more',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_01.png',
                ['object'] = 'prop_bush_neat_01',
                ['price'] = 95,
                ['label'] = 'Small medium tree',
                ['description'] = 'Small medium outdoor tree, it doesnt grow much more',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_08.png',
                ['object'] = 'prop_bush_neat_08',
                ['price'] = 230,
                ['label'] = 'Large tree',
                ['description'] = 'Large medium outdoor tree, it doesnt grow much more',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_02.png',
                ['object'] = 'prop_bush_neat_02',
                ['price'] = 120,
                ['label'] = 'Modern large tree',
                ['description'] = 'Modern large medium outdoor tree, it doesnt grow much more',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_dead_02.png',
                ['object'] = 'prop_bush_dead_02',
                ['price'] = 50,
                ['label'] = 'Horrible bush',
                ['description'] = 'Horrible dry desert bush',
                ['colorlabel'] = 'Gray',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_grape_01.png',
                ['object'] = 'prop_bush_grape_01',
                ['price'] = 250,
                ['label'] = 'Large vineyard',
                ['description'] = 'A fairly large and beautiful vineyard for outdoor farms',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_snow_bush_02_a.png',
                ['object'] = 'prop_snow_bush_02_a',
                ['price'] = 450,
                ['label'] = 'Snow and leaf grouting',
                ['description'] = 'A gathering of leaves with enormous snow',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_ornament_01.png',
                ['object'] = 'prop_bush_ornament_01',
                ['price'] = 290,
                ['label'] = 'Design tree',
                ['description'] = 'A tree pruned with beautiful details, it has multiple varieties',
                ['colorlabel'] = 'Green',
                ['colors'] = {
                    {
                        label = 'Design 02',
                        object = 'prop_bush_ornament_02',
                        price = 290
                    },
                    {
                        label = 'Design 03',
                        object = 'prop_bush_ornament_04',
                        price = 290
                    },
                    {
                        label = 'Design 04',
                        object = 'prop_bush_ornament_03',
                        price = 290
                    }
                }
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_04.png',
                ['object'] = 'prop_bush_neat_04',
                ['price'] = 190,
                ['label'] = 'Bush wall',
                ['description'] = 'Shrub wall to make extraordinary divisions',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/bush/prop_bush_neat_03.png',
                ['object'] = 'prop_bush_neat_03',
                ['price'] = 180,
                ['label'] = 'Crooked bush wall',
                ['description'] = 'Shrub wall to make extraordinary divisions',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            }
        }
    },
    ['tree'] = {
        label = 'Tree',
        img = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-tree-blue.svg',
        navigation = 5,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/garden/garden-tree-blue.svg',
        css = {
            width = 9,
            top = -1.0,
            left = -1.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_joshua_tree_02c.png',
                ['object'] = 'prop_joshua_tree_02c',
                ['price'] = 250,
                ['label'] = 'Little tree 01',
                ['description'] = 'Cute little tree',
                ['colorlabel'] = 'Little tree 01',
                ['colors'] = {
                    {
                        label = 'Little tree 02',
                        object = 'prop_joshua_tree_01b',
                        price = 250
                    },
                    {
                        label = 'Little tree 03',
                        object = 'prop_joshua_tree_02d',
                        price = 250
                    },
                    {
                        label = 'Little tree 04',
                        object = 'prop_joshua_tree_01a',
                        price = 250
                    },
                    {
                        label = 'Little tree 05',
                        object = 'prop_joshua_tree_01e',
                        price = 250
                    },
                    {
                        label = 'Little tree 06',
                        object = 'prop_joshua_tree_01d',
                        price = 250
                    },
                    {
                        label = 'Little tree 07',
                        object = 'prop_joshua_tree_01c',
                        price = 250
                    },
                    {
                        label = 'Little tree 08',
                        object = 'prop_joshua_tree_02b',
                        price = 250
                    },
                    {
                        label = 'Little tree 09',
                        object = 'prop_joshua_tree_02b',
                        price = 250
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_snow_tree_03_h.png',
                ['object'] = 'prop_snow_tree_03_h',
                ['price'] = 650,
                ['label'] = 'Huge snowy tree 01',
                ['description'] = 'Completely snowy or natural Christmas trees',
                ['colorlabel'] = 'Huge snowy tree 01',
                ['colors'] = {
                    {
                        label = 'Huge snowy tree 02',
                        object = 'prop_snow_tree_04_f',
                        price = 650
                    },
                    {
                        label = 'Huge snowy tree 03',
                        object = 'prop_snow_tree_03_i',
                        price = 650
                    },
                    {
                        label = 'Huge snowy tree 04',
                        object = 'prop_xmas_tree_int',
                        price = 650
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/garden/items/tree/test_tree_cedar_trunk_001.png',
                ['object'] = 'test_tree_cedar_trunk_001',
                ['price'] = 500,
                ['label'] = 'Long and thin tree',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Long 01',
                ['colors'] = {
                    {
                        label = 'Long 02',
                        object = 'prop_tree_cedar_s_01',
                        price = 500
                    },
                    {
                        label = 'Long 03',
                        object = 'prop_tree_cedar_s_04',
                        price = 500
                    },
                    {
                        label = 'Long 04',
                        object = 'prop_tree_cedar_04',
                        price = 500
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_fallen_01.png',
                ['object'] = 'prop_tree_fallen_01',
                ['price'] = 150,
                ['label'] = 'Broken tree',
                ['description'] = 'Broken tree, at a good price because you see... its broken haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/garden/items/tree/test_tree_forest_trunk_04.png',
                ['object'] = 'test_tree_forest_trunk_04',
                ['price'] = 700,
                ['label'] = 'Huge holey tree',
                ['description'] = 'This huge tree grows naturally with an internal deadhead, it seems like something magical, doesnt it?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_olive_01.png',
                ['object'] = 'prop_tree_olive_01',
                ['price'] = 420,
                ['label'] = 'Powerful tree',
                ['description'] = 'Powerful tree in size, it doesnt look like it will break and it is made of anthanium',
                ['colorlabel'] = 'Tree 01',
                ['colors'] = {
                    {
                        label = 'Tree 02',
                        object = 'prop_tree_olive_creator',
                        price = 400
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_eucalip_01.png',
                ['object'] = 'prop_tree_eucalip_01',
                ['price'] = 250,
                ['label'] = 'Huge eucalyptus',
                ['description'] = 'Huge eucalyptus tree, beautiful for outdoors and sun',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_stump_01.png',
                ['object'] = 'prop_tree_stump_01',
                ['price'] = 120,
                ['label'] = 'Half tree',
                ['description'] = 'Half a tree, what is that, wtf?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/garden/items/tree/prop_tree_eng_oak_creator.png',
                ['object'] = 'prop_tree_eng_oak_creator',
                ['price'] = 150,
                ['label'] = 'Olive tree 01',
                ['description'] = 'Designer olive tree, it has many olives and looks delicious',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_eng_oak_01.png',
                ['object'] = 'prop_tree_eng_oak_01',
                ['price'] = 170,
                ['label'] = 'Olive tree 02',
                ['description'] = 'Designer olive tree, it has many olives and looks delicious',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_maple_02.png',
                ['object'] = 'prop_tree_maple_02',
                ['price'] = 290,
                ['label'] = 'Maple tree',
                ['description'] = 'A maple tree with some oranges in it',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_lficus_06.png',
                ['object'] = 'prop_tree_lficus_06',
                ['price'] = 340,
                ['label'] = 'Dry tree as ass',
                ['description'] = 'A dry tree like an old ladys ass',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_birch_04.png',
                ['object'] = 'prop_tree_birch_04',
                ['price'] = 450,
                ['label'] = 'Bird tree',
                ['description'] = 'Bird tree, attractive for outdoors or large squares',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_mquite_01.png',
                ['object'] = 'prop_tree_mquite_01',
                ['price'] = 230,
                ['label'] = 'Park tree',
                ['description'] = 'Normal little tree that you would find in a square',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/garden/items/tree/test_tree_forest_trunk_base_01.png',
                ['object'] = 'test_tree_forest_trunk_base_01',
                ['price'] = 120,
                ['label'] = 'Old trunk',
                ['description'] = 'An old log, it seems to be at least two thousand years old, dont you think?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [16] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_jacada_02.png',
                ['object'] = 'prop_tree_jacada_02',
                ['price'] = 980,
                ['label'] = 'Sakura tree',
                ['description'] = 'Beautiful Sakura tree with pink leaves, I love it, it is expensive for its export!',
                ['colorlabel'] = 'Pink',
                ['colors'] = {}
            },
            [17] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_log_02.png',
                ['object'] = 'prop_tree_log_02',
                ['price'] = 90,
                ['label'] = 'Broken trunk',
                ['description'] = 'Its a piece of log but maybe its good for sitting on or for the cat to scratch?',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [18] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_cypress_01.png',
                ['object'] = 'prop_tree_cypress_01',
                ['price'] = 340,
                ['label'] = 'Large bush tree',
                ['description'] = 'A very tall tree with many leaves, huge and floral',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [19] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_tree_birch_05.png',
                ['object'] = 'prop_tree_birch_05',
                ['price'] = 210,
                ['label'] = 'Apple tree',
                ['description'] = 'A pretty apple tree, it can collect things',
                ['colorlabel'] = 'Green',
                ['colors'] = {}
            },
            [20] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/tree/prop_prop_tree_02.png',
                ['object'] = 'prop_prop_tree_02',
                ['price'] = 220,
                ['label'] = 'Tree with pot',
                ['description'] = 'A beautiful tree with a pot, but dont forget to put it outdoors!',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['cleaning'] = {
        label = 'Cleaning Robot',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/cleaning-robot.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/cleaning-robot.svg',
        css = {
            top = 8.3,
            left = 0.30,
            width = 3.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/cleaning-robot/qs_cleaning_robot_prop_01.png',
                ['object'] = 'qs_cleaning_robot_prop_01',
                ['price'] = 550,
                ['label'] = 'Cleaning Robot',
                ['description'] = 'Modern and minimalist smart cleaning robot designed for stylish interiors',
                ['colorlabel'] = 'White',
                onlyInside = true,
                isCleanerRobot = {
                    dockerModel = 'qs_robot_halt_prop_01',
                },
                ['colors'] = {
                    {
                        label = 'Blue',
                        object = 'qs_cleaning_robot_prop_02',
                        price = 550,
                        onlyInside = true,
                        isCleanerRobot = {
                            dockerModel = 'qs_robot_halt_prop_02',
                        },
                    },
                    {
                        label = 'Turquoise',
                        object = 'qs_cleaning_robot_prop_03',
                        price = 550,
                        onlyInside = true,
                        isCleanerRobot = {
                            dockerModel = 'qs_robot_halt_prop_03',
                        },
                    },
                    {
                        label = 'Gray',
                        object = 'qs_cleaning_robot_prop_04',
                        price = 550,
                        onlyInside = true,
                        isCleanerRobot = {
                            dockerModel = 'qs_robot_halt_prop_04',
                        },
                    },
                    {
                        label = 'Black',
                        object = 'qs_cleaning_robot_prop_05',
                        price = 550,
                        onlyInside = true,
                        isCleanerRobot = { dockerModel = 'qs_robot_halt_prop_05' },
                    },
                },
            }
        }
    },
    ['lamp'] = {
        label = 'Lamp',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-lamp-blue.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-lamp-blue.svg',
        css = {
            top = 1.8,
            left = 15.50,
            width = 2.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/apa_mp_h_floorlamp_a.png',
                ['object'] = 'apa_mp_h_floorlamp_a',
                ['price'] = 140,
                ['label'] = 'White modern lamp',
                ['description'] = 'Beautiful and minimalist white modern lamp',
                ['colorlabel'] = 'Modern Lamp 01',
                ['colors'] = {
                    {
                        label = 'Modern Lamp 01',
                        object = 'apa_mp_h_floorlamp_b',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 02',
                        object = 'apa_mp_h_floorlamp_c',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 03',
                        object = 'apa_mp_h_lit_floorlampnight_05',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 04',
                        object = 'apa_mp_h_lit_floorlampnight_07',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 05',
                        object = 'apa_mp_h_lit_floorlampnight_14',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 06',
                        object = 'apa_mp_h_lit_floorlamp_01',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 07',
                        object = 'apa_mp_h_lit_floorlamp_02',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 08',
                        object = 'apa_mp_h_lit_floorlamp_05',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 09',
                        object = 'apa_mp_h_lit_floorlamp_06',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 10',
                        object = 'apa_mp_h_lit_floorlamp_10',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 11',
                        object = 'apa_mp_h_lit_floorlamp_13',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 12',
                        object = 'apa_mp_h_lit_floorlamp_17',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 13',
                        object = 'hei_heist_lit_floorlamp_01',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 14',
                        object = 'hei_heist_lit_floorlamp_02',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 15',
                        object = 'hei_heist_lit_floorlamp_03',
                        price = 140
                    },
                    {
                        label = 'Modern Lamp 16',
                        object = 'hei_heist_lit_floorlamp_04',
                        price = 140
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/apa_mp_h_lit_lamptablenight_16.png',
                ['object'] = 'apa_mp_h_lit_lamptablenight_16',
                ['price'] = 80,
                ['label'] = 'Desk lamp',
                ['description'] = 'White lamp for light table, beautiful',
                ['colorlabel'] = 'Desk Lamp 01',
                ['colors'] = {
                    {
                        label = 'Desk Lamp 01',
                        object = 'apa_mp_h_lit_lamptablenight_24',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 02',
                        object = 'apa_mp_h_lit_lamptable_005',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 03',
                        object = 'apa_mp_h_lit_lamptable_02',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 04',
                        object = 'apa_mp_h_lit_lamptable_09',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 05',
                        object = 'apa_mp_h_lit_lamptable_14',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 06',
                        object = 'apa_mp_h_lit_lamptable_17',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 07',
                        object = 'apa_mp_h_lit_lamptable_21',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 08',
                        object = 'hei_heist_lit_lamptable_03',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 09',
                        object = 'hei_heist_lit_lamptable_04',
                        price = 80
                    },
                    {
                        label = 'Desk Lamp 10',
                        object = 'hei_heist_lit_lamptable_06',
                        price = 80
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/ch_prop_ch_lamp_ceiling_01a.png',
                ['object'] = 'ch_prop_ch_lamp_ceiling_01a',
                ['price'] = 150,
                ['label'] = 'Ceiling light',
                ['description'] = 'Ceiling lamp, there are many different models, you can choose one and it will be beautiful in your house',
                ['colorlabel'] = 'Ceiling 01',
                ['colors'] = {
                    {
                        label = 'Ceiling 02',
                        object = 'ch_prop_ch_lamp_ceiling_04a',
                        price = 150
                    },
                    {
                        label = 'Ceiling 03',
                        object = 'ch_prop_ch_lamp_ceiling_g_01a',
                        price = 150
                    },
                    {
                        label = 'Ceiling 04',
                        object = 'ch_prop_ch_lamp_ceiling_g_01b',
                        price = 150
                    },
                    {
                        label = 'Ceiling 05',
                        object = 'ch_prop_ch_lamp_ceiling_w_01a',
                        price = 150
                    },
                    {
                        label = 'Ceiling 06',
                        object = 'ch_prop_ch_lamp_ceiling_w_01b',
                        price = 150
                    },
                    {
                        label = 'Ceiling 07',
                        object = 'xm_base_cia_lamp_ceiling_02a',
                        price = 150
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/ch_prop_ch_tunnel_worklight.png',
                ['object'] = 'ch_prop_ch_tunnel_worklight',
                ['price'] = 230,
                ['label'] = 'Tunnel lamp',
                ['description'] = 'Normal tunnel lamp, illuminates very well',
                ['colorlabel'] = 'Yellow Work',
                ['colors'] = {
                    {
                        label = 'Yellow',
                        object = 'prop_construcionlamp_01',
                        price = 290
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/v_ret_fh_walllighton.png',
                ['object'] = 'v_ret_fh_walllighton',
                ['price'] = 30,
                ['label'] = 'Candle lamp',
                ['description'] = 'Wall lamp with candles, harmonious',
                ['colorlabel'] = 'On',
                ['colors'] = {
                    {
                        label = 'Off',
                        object = 'v_ret_fh_walllightoff',
                        price = 30
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/hei_heist_lit_lightpendant_01.png',
                ['object'] = 'hei_heist_lit_lightpendant_01',
                ['price'] = 100,
                ['label'] = 'Square ceiling lamp',
                ['description'] = 'Beautiful square ceiling lamp with details',
                ['colorlabel'] = 'Light 01',
                ['colors'] = {
                    {
                        label = 'Light 02',
                        object = 'hei_heist_lit_lightpendant_02',
                        price = 100
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/lamp/prop_wall_light_08a.png',
                ['object'] = 'prop_wall_light_08a',
                ['price'] = 40,
                ['label'] = 'Small outdoor lamps',
                ['description'] = 'Plastic and waterproof outdoor lamps',
                ['colorlabel'] = 'Lamp 01',
                ['colors'] = {
                    {
                        label = 'Lamp 02',
                        object = 'prop_wall_light_11',
                        price = 40
                    },
                    {
                        label = 'Lamp 03',
                        object = 'prop_wall_light_12',
                        price = 40
                    },
                    {
                        label = 'Lamp 04',
                        object = 'prop_wall_light_17b',
                        price = 40
                    },
                    {
                        label = 'Lamp 05',
                        object = 'prop_wall_light_18a',
                        price = 40
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/lamp/prop_beer_neon_01.png',
                ['object'] = 'prop_beer_neon_01',
                ['price'] = 250,
                ['label'] = 'Bar sign',
                ['description'] = 'Beautiful neon signs for businesses',
                ['colorlabel'] = 'Neon 01',
                ['colors'] = {
                    {
                        label = 'Neon 02',
                        object = 'prop_beer_neon_02',
                        price = 250
                    },
                    {
                        label = 'Neon 03',
                        object = 'prop_beer_neon_03',
                        price = 250
                    },
                    {
                        label = 'Neon 04',
                        object = 'prop_beer_neon_04',
                        price = 250
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/vw_prop_casino_art_lampf_01a.png',
                ['object'] = 'vw_prop_casino_art_lampf_01a',
                ['price'] = 85,
                ['label'] = 'Design lamp',
                ['description'] = 'Eccentric lamp design, very beautiful',
                ['colorlabel'] = 'Colored',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/bkr_prop_fakeid_desklamp_01a.png',
                ['object'] = 'bkr_prop_fakeid_desklamp_01a',
                ['price'] = 30,
                ['label'] = 'Lamp with magnifying glass',
                ['description'] = 'A lamp for clinics',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/h4_prop_battle_lights_wall_l_b.png',
                ['object'] = 'h4_prop_battle_lights_wall_l_b',
                ['price'] = 80,
                ['label'] = 'Luxury pink lamp',
                ['description'] = 'Detailed antique design pink wall lamp',
                ['colorlabel'] = 'Pink',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/lamp/v_res_tre_lightfan.png',
                ['object'] = 'v_res_tre_lightfan',
                ['price'] = 180,
                ['label'] = 'Ceiling fan',
                ['description'] = 'Ceiling lamp with lights, it doesnt usually turn often because its a prop haha',
                ['colorlabel'] = 'Brown',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/lamp/v_med_examlight.png',
                ['object'] = 'v_med_examlight',
                ['price'] = 130,
                ['label'] = 'Dentist lamp',
                ['description'] = 'Lamp for dentist offices, it has a huge magnifying glass and a beautiful white LED light',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/lamp/apa_mp_h_floor_lamp_int_08.png',
                ['object'] = 'apa_mp_h_floor_lamp_int_08',
                ['price'] = 110,
                ['label'] = 'Floor lamp',
                ['description'] = 'Normal floor lamp, it doesnt have very good details but it is the most standard on the market',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            }
        }
    },
    ['plant'] = {
        label = 'Plant',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-plant-blue.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-plant-blue.svg',
        css = {
            top = 4.6,
            left = 17.5,
            width = 2.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/plant/prop_plant_int_02a.png',
                ['object'] = 'prop_plant_int_02a',
                ['price'] = 140,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                ['colorlabel'] = 'Plant 01',
                ['colors'] = {
                    {
                        label = 'Plant 02',
                        object = 'prop_plant_int_02b',
                        price = 140
                    },
                    {
                        label = 'Plant 03',
                        object = 'prop_plant_int_05a',
                        price = 140
                    },
                    {
                        label = 'Plant 04',
                        object = 'prop_plant_int_05b',
                        price = 140
                    },
                    {
                        label = 'Plant 05',
                        object = 'prop_plant_int_06a',
                        price = 140
                    },
                    {
                        label = 'Plant 06',
                        object = 'prop_plant_int_06b',
                        price = 140
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/plant/prop_pot_plant_02a.png',
                ['object'] = 'prop_pot_plant_02a',
                ['price'] = 250,
                ['label'] = 'Pot Plant',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Pot 01',
                ['colors'] = {
                    {
                        label = 'Pot 02',
                        object = 'prop_pot_plant_02b',
                        price = 250
                    },
                    {
                        label = 'Pot 03',
                        object = 'prop_pot_plant_02c',
                        price = 250
                    },
                    {
                        label = 'Pot 04',
                        object = 'prop_pot_plant_02d',
                        price = 250
                    },
                    {
                        label = 'Pot 05',
                        object = 'prop_pot_plant_03a',
                        price = 250
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/p_int_jewel_plant_01.png',
                ['object'] = 'p_int_jewel_plant_01',
                ['price'] = 450,
                ['label'] = 'Jewel Plant',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Jewel 01',
                ['colors'] = {
                    {
                        label = 'Jewel 02',
                        object = 'p_int_jewel_plant_02',
                        price = 450
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/vw_prop_casino_art_plant_01a.png',
                ['object'] = 'vw_prop_casino_art_plant_01a',
                ['price'] = 300,
                ['label'] = 'Art Plant',
                ['description'] = 'Indoor plants, used in the grand casino',
                ['colorlabel'] = 'Plant 01',
                ['colors'] = {
                    {
                        label = 'Plant 02',
                        object = 'vw_prop_casino_art_plant_02a',
                        price = 300
                    },
                    {
                        label = 'Plant 03',
                        object = 'vw_prop_casino_art_plant_03a',
                        price = 300
                    },
                    {
                        label = 'Plant 04',
                        object = 'vw_prop_casino_art_plant_04a',
                        price = 300
                    },
                    {
                        label = 'Plant 05',
                        object = 'vw_prop_casino_art_plant_05a',
                        price = 300
                    },
                    {
                        label = 'Plant 06',
                        object = 'vw_prop_casino_art_plant_06a',
                        price = 300
                    },
                    {
                        label = 'Plant 07',
                        object = 'vw_prop_casino_art_plant_07a',
                        price = 300
                    },
                    {
                        label = 'Plant 08',
                        object = 'vw_prop_casino_art_plant_08a',
                        price = 300
                    },
                    {
                        label = 'Plant 09',
                        object = 'vw_prop_casino_art_plant_09a',
                        price = 300
                    },
                    {
                        label = 'Plant 10',
                        object = 'vw_prop_casino_art_plant_10a',
                        price = 300
                    },
                    {
                        label = 'Plant 11',
                        object = 'vw_prop_casino_art_plant_11a',
                        price = 300
                    },
                    {
                        label = 'Plant 12',
                        object = 'vw_prop_casino_art_plant_12a',
                        price = 300
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/bkr_prop_weed_bucket_01a.png',
                ['object'] = 'bkr_prop_weed_bucket_01a',
                ['price'] = 450,
                ['label'] = 'Weed care',
                ['description'] = 'All types of weed plants for your home',
                ['colorlabel'] = 'Weed 01',
                ['colors'] = {
                    {
                        label = 'Weed 02',
                        object = 'bkr_prop_weed_bucket_01b',
                        price = 450
                    },
                    {
                        label = 'Weed 03',
                        object = 'bkr_prop_weed_bucket_01c',
                        price = 450
                    },
                    {
                        label = 'Weed 04',
                        object = 'bkr_prop_weed_bucket_01d',
                        price = 450
                    },
                    {
                        label = 'Weed 05',
                        object = 'bkr_prop_weed_bucket_open_01a',
                        price = 450
                    },
                    {
                        label = 'Weed 06',
                        object = 'bkr_prop_weed_plantpot_stack_01b',
                        price = 450
                    },
                    {
                        label = 'Weed 07',
                        object = 'bkr_prop_weed_plantpot_stack_01c',
                        price = 450
                    },
                    {
                        label = 'Weed 08',
                        object = 'bkr_prop_weed_fan_ceiling_01a',
                        price = 450
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/apa_mp_h_acc_plant_palm_01.png',
                ['object'] = 'apa_mp_h_acc_plant_palm_01',
                ['price'] = 230,
                ['label'] = 'Palm',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/apa_mp_h_acc_plant_tall_01.png',
                ['object'] = 'apa_mp_h_acc_plant_tall_01',
                ['price'] = 120,
                ['label'] = 'Tall',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/plant/ch_prop_ch_planter_01.png',
                ['object'] = 'ch_prop_ch_planter_01',
                ['price'] = 180,
                ['label'] = 'Planter',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/plant/prop_fbibombplant.png',
                ['object'] = 'prop_fbibombplant',
                ['price'] = 210,
                ['label'] = 'FBI Bomb plant',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Color for default',
                ['colors'] = {}
            }
        }
    },
    ['tv'] = {
        label = 'Tv',
        img = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-tv-blue.svg',
        navigation = 4,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/living-room/livingroom-tv-blue.svg',
        css = {
            top = 5.7,
            left = 9.9,
            width = 5.0,
            zIndex = 3
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/ex_office_swag_electronic.png',
                ['object'] = 'ex_office_swag_electronic',
                ['price'] = 500,
                ['label'] = 'Swag Electronic',
                ['description'] = 'Televisions with the greatest swag of all housing!',
                ['colorlabel'] = 'Swag 01',
                ['colors'] = {
                    {
                        label = 'Swag 02',
                        object = 'ex_office_swag_electronic2',
                        price = 500
                    },
                    {
                        label = 'Swag 03',
                        object = 'ex_office_swag_electronic3',
                        price = 500
                    }
                }
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/tv/ex_prop_ex_tv_flat_01.png',
                ['object'] = 'ex_prop_ex_tv_flat_01',
                ['price'] = 1200,
                ['label'] = 'TV',
                ['description'] = 'All types of high-end televisions',
                ['colorlabel'] = 'TV 01',
                ['colors'] = {
                    {
                        label = 'TV 01',
                        object = 'gr_prop_gr_trailer_tv',
                        price = 1200
                    },
                    {
                        label = 'TV 02',
                        object = 'prop_trev_tv_01',
                        price = 700
                    },
                    {
                        label = 'TV 03',
                        object = 'prop_tv_02',
                        price = 320
                    },
                    {
                        label = 'TV 04',
                        object = 'prop_tv_03',
                        price = 450
                    },
                    {
                        label = 'TV 05',
                        object = 'prop_tv_04',
                        price = 120
                    },
                    {
                        label = 'TV 06',
                        object = 'prop_tv_05',
                        price = 480
                    },
                    {
                        label = 'TV 07',
                        object = 'prop_tv_06',
                        price = 480
                    },
                    {
                        label = 'TV 08',
                        object = 'prop_tv_07',
                        price = 480
                    },
                    {
                        label = 'TV 09',
                        object = 'prop_tv_flat_01',
                        price = 1500
                    },
                    {
                        label = 'TV 10',
                        object = 'prop_tv_flat_02',
                        price = 1500
                    },
                    {
                        label = 'TV 11',
                        object = 'prop_tv_flat_02b',
                        price = 1500
                    },
                    {
                        label = 'TV 12',
                        object = 'prop_tv_flat_03',
                        price = 2000
                    },
                    {
                        label = 'TV 13',
                        object = 'sm_prop_smug_tv_flat_01',
                        price = 2000
                    },
                    {
                        label = 'TV 14',
                        object = 'vw_prop_vw_cinema_tv_01',
                        price = 2000
                    },
                    {
                        label = 'TV 15',
                        object = 'xm_prop_x17_tv_ceiling_01',
                        price = 2000
                    },
                    {
                        label = 'TV 16',
                        object = 'xm_prop_x17_tv_stand_01a',
                        price = 2000
                    }
                }
            },
            [3] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/apa_mp_h_str_avunits_01.png',
                ['object'] = 'apa_mp_h_str_avunits_01',
                ['price'] = 2200,
                ['label'] = 'Exclusive TV',
                ['description'] = 'Exclusive luxury televisions',
                ['colorlabel'] = 'Exclusive 01',
                ['colors'] = {
                    {
                        label = 'Exclusive 02',
                        object = 'apa_mp_h_str_avunitm_03',
                        price = 2200
                    },
                    {
                        label = 'Exclusive 03',
                        object = 'apa_mp_h_str_avunitl_04',
                        price = 1500
                    },
                    {
                        label = 'Exclusive 04',
                        object = 'apa_mp_h_str_avunitl_04',
                        price = 1600
                    },
                    {
                        label = 'Exclusive 05',
                        object = 'hei_heist_str_avunitl_03',
                        price = 1600
                    },
                    {
                        label = 'Exclusive 06',
                        object = 'hei_heist_str_avunits_01',
                        price = 1600
                    },
                    {
                        label = 'Exclusive 07',
                        object = 'apa_mp_h_str_avunitl_01_b',
                        price = 6800
                    },
                    {
                        label = 'Exclusive 08',
                        object = 'hei_heist_str_avunitl_01',
                        price = 6800
                    }
                }
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/tv/prop_cs_cctv.png',
                ['object'] = 'prop_cs_cctv',
                ['price'] = 130,
                ['label'] = 'CCTV',
                ['description'] = 'Quasar Store brand general televisions, the best on the market in low quality, lie...',
                ['colorlabel'] = 'CCTV 01',
                ['colors'] = {
                    {
                        label = 'CCTV 02',
                        object = 'prop_cctv_cam_01b',
                        price = 120
                    },
                    {
                        label = 'CCTV 03',
                        object = 'prop_cctv_cam_02a',
                        price = 135
                    },
                    {
                        label = 'CCTV 03',
                        object = 'prop_cctv_cam_03a',
                        price = 135
                    },
                    {
                        label = 'CCTV 04',
                        object = 'prop_cctv_cam_04a',
                        price = 155
                    },
                    {
                        label = 'CCTV 05',
                        object = 'prop_cctv_cam_04b',
                        price = 250
                    },
                    {
                        label = 'CCTV 06',
                        object = 'prop_cctv_cam_04c',
                        price = 250
                    },
                    {
                        label = 'CCTV 07',
                        object = 'prop_cctv_cam_05a',
                        price = 250
                    },
                    {
                        label = 'CCTV 08',
                        object = 'prop_cctv_cam_06a',
                        price = 120
                    },
                    {
                        label = 'CCTV 09',
                        object = 'prop_cctv_cam_07a',
                        price = 160
                    },
                    {
                        label = 'CCTV 10',
                        object = 'prop_cctv_pole_01a',
                        price = 230
                    },
                    {
                        label = 'CCTV 11',
                        object = 'prop_cctv_pole_02',
                        price = 480
                    },
                    {
                        label = 'CCTV 12',
                        object = 'prop_cctv_pole_03',
                        price = 480
                    },
                    {
                        label = 'CCTV 13',
                        object = 'prop_cctv_pole_04',
                        price = 500
                    },
                    {
                        label = 'CCTV 14',
                        object = 'prop_cctv_01_sm',
                        price = 450
                    },
                    {
                        label = 'CCTV 15',
                        object = 'prop_cctv_02_sm',
                        price = 800
                    },
                    {
                        label = 'CCTV 16',
                        object = 'prop_cctv_unit_02',
                        price = 800
                    },
                    {
                        label = 'CCTV 17',
                        object = 'prop_cctv_unit_04',
                        price = 1700
                    },
                    {
                        label = 'CCTV 18',
                        object = 'prop_cctv_unit_05',
                        price = 2500
                    },
                    {
                        label = 'CCTV 19',
                        object = 'apa_mp_h_str_avunitm_03',
                        price = 3200
                    },
                    {
                        label = 'CCTV 20',
                        object = 'prop_dest_cctv_02',
                        price = 900
                    },
                    {
                        label = 'CCTV 21',
                        object = 'prop_dest_cctv_03',
                        price = 900
                    },
                    {
                        label = 'CCTV 22',
                        object = 'prop_dest_cctv_03b',
                        price = 900
                    }
                }
            },
            [5] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/ex_prop_tv_settop_remote.png',
                ['object'] = 'ex_prop_tv_settop_remote',
                ['price'] = 10,
                ['label'] = 'Remote TV',
                ['description'] = 'Remote controls for general televisions',
                ['colorlabel'] = 'Remote 01',
                ['colors'] = {
                    {
                        label = 'Remote 02',
                        object = 'prop_cs_remote_01',
                        price = 10
                    },
                    {
                        label = 'Remote 03',
                        object = 'v_res_tre_remote',
                        price = 10
                    },
                    {
                        label = 'Remote 04',
                        object = 'v_res_tt_tvremote',
                        price = 15
                    }
                }
            },
            [6] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/tv/prop_monitor_01c.png',
                ['object'] = 'prop_monitor_01c',
                ['price'] = 150,
                ['label'] = 'Monitors',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'Monitors 01',
                ['colors'] = {
                    {
                        label = 'Monitors 02',
                        object = 'prop_monitor_01d',
                        price = 150
                    },
                    {
                        label = 'Monitors 03',
                        object = 'prop_monitor_02',
                        price = 150
                    },
                    {
                        label = 'Monitors 04',
                        object = 'prop_monitor_03b',
                        price = 150
                    },
                    {
                        label = 'Monitors 05',
                        object = 'prop_trailer_monitor_01',
                        price = 350
                    },
                    {
                        label = 'Monitors 06',
                        object = 'sm_prop_smug_monitor_01',
                        price = 250
                    },
                    {
                        label = 'Monitors 07',
                        object = 'v_res_monitor',
                        price = 150
                    },
                    {
                        label = 'Monitors 08',
                        object = 'xm_prop_x17_screens_02a',
                        price = 1600
                    }
                }
            },
            [7] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/ch_prop_arcade_claw_01a.png',
                ['object'] = 'ch_prop_arcade_claw_01a',
                ['price'] = 1200,
                ['label'] = 'Arcade',
                ['description'] = 'Super fun arcade machines and all the existing games',
                ['colorlabel'] = 'Arcade 01',
                ['colors'] = {
                    {
                        label = 'Arcade 02',
                        object = 'ch_prop_arcade_degenatron_01a',
                        price = 1400
                    },
                    {
                        label = 'Arcade 03',
                        object = 'ch_prop_arcade_fortune_01a',
                        price = 1800
                    },
                    {
                        label = 'Arcade 04',
                        object = 'ch_prop_arcade_fortune_door_01a',
                        price = 1400
                    },
                    {
                        label = 'Arcade 05',
                        object = 'ch_prop_arcade_gun_01a',
                        price = 1600
                    },
                    {
                        label = 'Arcade 06',
                        object = 'ch_prop_arcade_invade_01a',
                        price = 1800
                    },
                    {
                        label = 'Arcade 07',
                        object = 'ch_prop_arcade_love_01a',
                        price = 1800
                    },
                    {
                        label = 'Arcade 08',
                        object = 'ch_prop_arcade_monkey_01a',
                        price = 1600
                    },
                    {
                        label = 'Arcade 09',
                        object = 'ch_prop_arcade_penetrator_01a',
                        price = 150
                    },
                    {
                        label = 'Arcade 10',
                        object = 'ch_prop_arcade_race_01a',
                        price = 1600
                    },
                    {
                        label = 'Arcade 11',
                        object = 'ch_prop_arcade_race_01b',
                        price = 1500
                    },
                    {
                        label = 'Arcade 12',
                        object = 'ch_prop_arcade_space_01a',
                        price = 1500
                    },
                    {
                        label = 'Arcade 13',
                        object = 'ch_prop_arcade_street_01a',
                        price = 1600
                    },
                    {
                        label = 'Arcade 14',
                        object = 'ch_prop_arcade_street_01a_off',
                        price = 1500
                    },
                    {
                        label = 'Arcade 15',
                        object = 'ch_prop_arcade_street_01b',
                        price = 4300
                    },
                    {
                        label = 'Arcade 16',
                        object = 'ch_prop_arcade_street_01b_off',
                        price = 4300
                    },
                    {
                        label = 'Arcade 17',
                        object = 'ch_prop_arcade_street_01c',
                        price = 1500
                    },
                    {
                        label = 'Arcade 18',
                        object = 'ch_prop_arcade_street_01c_off',
                        price = 1500
                    },
                    {
                        label = 'Arcade 19',
                        object = 'ch_prop_arcade_street_01d',
                        price = 1500
                    },
                    {
                        label = 'Arcade 20',
                        object = 'ch_prop_arcade_street_01d_off',
                        price = 1500
                    },
                    {
                        label = 'Arcade 21',
                        object = 'ch_prop_arcade_street_02b',
                        price = 1500
                    },
                    {
                        label = 'Arcade 22',
                        object = 'ch_prop_arcade_wizard_01a',
                        price = 1500
                    },
                    {
                        label = 'Arcade 23',
                        object = 'prop_bball_arcade_01',
                        price = 1500
                    },
                    {
                        label = 'Arcade 24',
                        object = 'sum_prop_arcade_strength_01a',
                        price = 1500
                    },
                    {
                        label = 'Arcade 25',
                        object = 'sum_prop_arcade_strength_ham_01a',
                        price = 150
                    },
                    {
                        label = 'Arcade 26',
                        object = 'sum_prop_arcade_qub3d_01a',
                        price = 1600
                    }
                }
            },
            [8] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/ba_prop_battle_dj_deck_01a.png',
                ['object'] = 'ba_prop_battle_dj_deck_01a',
                ['price'] = 120,
                ['label'] = 'DJ',
                ['description'] = 'Description for Prop',
                ['colorlabel'] = 'DJ 01',
                ['colors'] = {
                    {
                        label = 'DJ 02',
                        object = 'ba_prop_battle_dj_kit_mixer',
                        price = 350
                    },
                    {
                        label = 'DJ 03',
                        object = 'ba_prop_battle_dj_mixer_01a',
                        price = 450
                    },
                    {
                        label = 'DJ 04',
                        object = 'ba_prop_battle_dj_mixer_01b',
                        price = 800
                    },
                    {
                        label = 'DJ 05',
                        object = 'ba_prop_battle_dj_mixer_01c',
                        price = 450
                    },
                    {
                        label = 'DJ 06',
                        object = 'ba_prop_battle_dj_mixer_01d',
                        price = 380
                    },
                    {
                        label = 'DJ 07',
                        object = 'ba_prop_battle_dj_mixer_01e',
                        price = 420
                    },
                    {
                        label = 'DJ 08',
                        object = 'ba_prop_battle_dj_stand',
                        price = 1450
                    }
                }
            },
            [9] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/tv/v_res_vacuum.png',
                ['object'] = 'v_res_vacuum',
                ['price'] = 350,
                ['label'] = 'Vacuum cleaner',
                ['description'] = 'A very comfortable and beautiful floor vacuum cleaner',
                ['colorlabel'] = 'Red',
                ['colors'] = {}
            },
            [10] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/bkr_prop_weed_fan_floor_01a.png',
                ['object'] = 'bkr_prop_weed_fan_floor_01a',
                ['price'] = 450,
                ['label'] = 'Standing fan',
                ['description'] = 'Cheap standing fan, very good for summer haha',
                ['colorlabel'] = 'White',
                ['colors'] = {}
            },
            [11] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/bkr_prop_clubhouse_jukebox_01a.png',
                ['object'] = 'bkr_prop_clubhouse_jukebox_01a',
                ['price'] = 800,
                ['label'] = 'Black jukebox',
                ['description'] = 'A large black jukebox with dark and dark music (hardcore)',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [12] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/bkr_prop_clubhouse_jukebox_01b.png',
                ['object'] = 'bkr_prop_clubhouse_jukebox_01b',
                ['price'] = 920,
                ['label'] = 'Colorful jukebox',
                ['description'] = 'A colorful jukebox with music from My Little Pony, I love Pinkie Pie, yes... so what?',
                ['colorlabel'] = 'Color',
                ['colors'] = {}
            },
            [13] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/bkr_prop_clubhouse_jukebox_02a.png',
                ['object'] = 'bkr_prop_clubhouse_jukebox_02a',
                ['price'] = 1200,
                ['label'] = 'Wooden jukebox',
                ['description'] = 'Wooden jukebox with old music, from the 80s',
                ['colorlabel'] = 'Wood',
                ['colors'] = {}
            },
            [14] = {
                ['img'] = Config.ImagePath ..
                    'decorate/categories/rooms/living-room/items/tv/hei_prop_hei_carrier_disp_01.png',
                ['object'] = 'hei_prop_hei_carrier_disp_01',
                ['price'] = 700,
                ['label'] = 'Radar screen',
                ['description'] = 'Radar screen for submarines, but it could pass for a TV haha',
                ['colorlabel'] = 'Black',
                ['colors'] = {}
            },
            [15] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/living-room/items/tv/prop_arcade_01.png',
                ['object'] = 'prop_arcade_01',
                ['price'] = 900,
                ['label'] = 'Arcade Machine Deluxe',
                ['description'] = 'A multicolored machine with bears and somewhat gay games, its epic by the way',
                ['colorlabel'] = 'Color',
                ['colors'] = {}
            }
        }
    },
    ['doors'] = {
        label = 'Cleaning Robot',
        img = Config.ImagePath .. 'decorate/categories/rooms/garden/doors.svg',
        navigation = 5,
        dynamic = true,
        dynamicIcon = Config.ImagePath .. 'decorate/categories/rooms/garden/doors.svg',
        css = {
            top = 6.5,
            left = 16.0,
            width = 3.5
        },
        items = {
            [1] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/doors/v_ilev_ph_gendoor002.png',
                ['object'] = 'v_ilev_ph_gendoor002',
                ['price'] = 350,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                isDoor = true
            },
            [2] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/doors/v_ilev_ra_door2.png',
                ['object'] = 'v_ilev_ra_door2',
                ['price'] = 350,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                isDoor = true
            },
            [3] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/doors/v_ilev_gtdoor02.png',
                ['object'] = 'v_ilev_gtdoor02',
                ['price'] = 350,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                isDoor = true
            },
            [4] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/doors/v_ilev_housedoor1.png',
                ['object'] = 'v_ilev_housedoor1',
                ['price'] = 350,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                isDoor = true
            },
            [5] = {
                ['img'] = Config.ImagePath .. 'decorate/categories/rooms/garden/items/doors/v_ilev_janitor_frontdoor.png',
                ['object'] = 'v_ilev_janitor_frontdoor',
                ['price'] = 350,
                ['label'] = 'Indoor plants',
                ['description'] = 'The best cared for indoor plants in Los Santos',
                isDoor = true
            },
        }
    },
}
