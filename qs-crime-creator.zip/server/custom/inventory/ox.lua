if Config.Inventory ~= 'ox' then
    return
end

local IMAGE_PATH = GetConvar('inventory:imagepath', 'nui://ox_inventory/web/images')

local function setImagePath(path)
    if path then
        return path:match('^[%w]+://') and path or ('%s/%s'):format(IMAGE_PATH, path)
    end
end

--ox_inventory/modules/items/shared.lua
---@diagnostic disable-next-line: duplicate-set-field
function sv_inventory:formatItemList()
    local itemList = {}
    for k, v in pairs(lib.load('@ox_inventory.data.items')) do
        local defaultImage = k .. '.png'
        itemList[k] = {
            name = k,
            label = v.label,
            image = setImagePath(v.client and v.client.image or defaultImage),
            isWeapon = false,
            client = v.client or {},
        }
    end
    for type, data in pairs(lib.load('@ox_inventory.data.weapons')) do
        for k, v in pairs(data) do
            local defaultImage = k .. '.png'
            itemList[k] = {
                name = k,
                label = v.label,
                image = setImagePath(v.client and v.client.image or defaultImage),
                isWeapon = v.weapon or false,
                client = v.client or {},
                type = v.type,
            }
            itemList[k][type == 'Ammo' and 'ammo' or type == 'Components' and 'component' or type == 'Tints' and 'tint' or 'weapon'] = true
        end
    end
    return itemList
end
